--
-- PostgreSQL database dump
--

\restrict Pabu7q0VYjHGBkN7scfqq0PYmvsmNukhchevPZ3KM12CkHEz3hcjHq61WCvFwkU

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

-- Started on 2025-11-03 17:18:33

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 2 (class 3079 OID 16389)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- TOC entry 5289 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 257 (class 1255 OID 16759)
-- Name: check_tenant_limits(integer, character varying); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.check_tenant_limits(p_tenant_id integer, p_resource_type character varying) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_count INTEGER;
    v_limit INTEGER := 1000; -- Default limit
BEGIN
    CASE p_resource_type
        WHEN 'employees' THEN
            SELECT COUNT(*) INTO v_count FROM employees WHERE tenant_id = p_tenant_id;
        WHEN 'inventory' THEN
            SELECT COUNT(*) INTO v_count FROM inventory_items WHERE tenant_id = p_tenant_id;
        WHEN 'bills' THEN
            SELECT COUNT(*) INTO v_count FROM bills 
            WHERE tenant_id = p_tenant_id 
            AND bill_date >= CURRENT_DATE - INTERVAL '30 days';
            v_limit := 10000;
        ELSE
            RETURN TRUE;
    END CASE;
    
    RETURN v_count < v_limit;
END;
$$;


ALTER FUNCTION public.check_tenant_limits(p_tenant_id integer, p_resource_type character varying) OWNER TO postgres;

--
-- TOC entry 258 (class 1255 OID 16760)
-- Name: get_tenant_stats(integer); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.get_tenant_stats(p_tenant_id integer) RETURNS TABLE(stat_name character varying, stat_value numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 'total_employees'::VARCHAR, COUNT(*)::NUMERIC FROM employees WHERE tenant_id = p_tenant_id AND status = 'Active'
    UNION ALL
    SELECT 'total_products'::VARCHAR, COUNT(*)::NUMERIC FROM inventory_items WHERE tenant_id = p_tenant_id
    UNION ALL
    SELECT 'total_bills'::VARCHAR, COUNT(*)::NUMERIC FROM bills WHERE tenant_id = p_tenant_id
    UNION ALL
    SELECT 'total_revenue'::VARCHAR, COALESCE(SUM(grand_total), 0) FROM bills WHERE tenant_id = p_tenant_id
    UNION ALL
    SELECT 'monthly_revenue'::VARCHAR, COALESCE(SUM(grand_total), 0) 
    FROM bills WHERE tenant_id = p_tenant_id AND bill_date >= DATE_TRUNC('month', CURRENT_DATE);
END;
$$;


ALTER FUNCTION public.get_tenant_stats(p_tenant_id integer) OWNER TO postgres;

--
-- TOC entry 256 (class 1255 OID 16736)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 231 (class 1259 OID 16550)
-- Name: attendance_leaves; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.attendance_leaves (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    employee_id integer NOT NULL,
    date date NOT NULL,
    status character varying(20) DEFAULT 'Present'::character varying,
    leave_type character varying(50),
    reason text,
    approved_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT attendance_leaves_status_check CHECK (((status)::text = ANY ((ARRAY['Present'::character varying, 'Absent'::character varying, 'Half Day'::character varying, 'Leave'::character varying])::text[])))
);


ALTER TABLE public.attendance_leaves OWNER TO postgres;

--
-- TOC entry 5290 (class 0 OID 0)
-- Dependencies: 231
-- Name: TABLE attendance_leaves; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.attendance_leaves IS 'Stores employee attendance and leave records with tenant isolation';


--
-- TOC entry 230 (class 1259 OID 16549)
-- Name: attendance_leaves_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.attendance_leaves_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.attendance_leaves_id_seq OWNER TO postgres;

--
-- TOC entry 5291 (class 0 OID 0)
-- Dependencies: 230
-- Name: attendance_leaves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.attendance_leaves_id_seq OWNED BY public.attendance_leaves.id;


--
-- TOC entry 239 (class 1259 OID 16683)
-- Name: audit_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    tenant_id integer,
    event_type character varying(50) NOT NULL,
    user_id integer,
    user_type character varying(20),
    ip_address character varying(45),
    user_agent text,
    details jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT audit_log_user_type_check CHECK (((user_type)::text = ANY ((ARRAY['tenant'::character varying, 'employee'::character varying])::text[])))
);


ALTER TABLE public.audit_log OWNER TO postgres;

--
-- TOC entry 5292 (class 0 OID 0)
-- Dependencies: 239
-- Name: TABLE audit_log; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.audit_log IS 'Stores audit trail of all system events';


--
-- TOC entry 238 (class 1259 OID 16682)
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO postgres;

--
-- TOC entry 5293 (class 0 OID 0)
-- Dependencies: 238
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- TOC entry 229 (class 1259 OID 16516)
-- Name: bill_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bill_items (
    item_id integer NOT NULL,
    tenant_id integer NOT NULL,
    bill_id integer NOT NULL,
    item_code character varying(50) NOT NULL,
    item_name character varying(100) NOT NULL,
    item_price numeric(10,2) NOT NULL,
    quantity integer NOT NULL,
    total numeric(10,2) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.bill_items OWNER TO postgres;

--
-- TOC entry 5294 (class 0 OID 0)
-- Dependencies: 229
-- Name: TABLE bill_items; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.bill_items IS 'Stores individual items in bills with tenant isolation';


--
-- TOC entry 228 (class 1259 OID 16515)
-- Name: bill_items_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bill_items_item_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bill_items_item_id_seq OWNER TO postgres;

--
-- TOC entry 5295 (class 0 OID 0)
-- Dependencies: 228
-- Name: bill_items_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bill_items_item_id_seq OWNED BY public.bill_items.item_id;


--
-- TOC entry 227 (class 1259 OID 16483)
-- Name: bills; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.bills (
    bill_id integer NOT NULL,
    tenant_id integer NOT NULL,
    bill_date timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    customer_name character varying(100),
    customer_phone character varying(15),
    customer_age_group character varying(20),
    subtotal numeric(10,2) NOT NULL,
    gst numeric(10,2) NOT NULL,
    discount numeric(10,2) DEFAULT 0.00,
    grand_total numeric(10,2) NOT NULL,
    payment_method character varying(20) NOT NULL,
    created_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT bills_customer_age_group_check CHECK (((customer_age_group)::text = ANY ((ARRAY['kid'::character varying, 'teen'::character varying, 'adult'::character varying, 'old'::character varying])::text[]))),
    CONSTRAINT bills_payment_method_check CHECK (((payment_method)::text = ANY ((ARRAY['Cash'::character varying, 'UPI'::character varying, 'Credit'::character varying, 'Debit'::character varying, 'Card'::character varying])::text[])))
);


ALTER TABLE public.bills OWNER TO postgres;

--
-- TOC entry 5296 (class 0 OID 0)
-- Dependencies: 227
-- Name: TABLE bills; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.bills IS 'Stores billing records with tenant isolation';


--
-- TOC entry 226 (class 1259 OID 16482)
-- Name: bills_bill_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.bills_bill_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.bills_bill_id_seq OWNER TO postgres;

--
-- TOC entry 5297 (class 0 OID 0)
-- Dependencies: 226
-- Name: bills_bill_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.bills_bill_id_seq OWNED BY public.bills.bill_id;


--
-- TOC entry 223 (class 1259 OID 16426)
-- Name: employees; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.employees (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    phone character varying(20),
    department character varying(50),
    role character varying(50) DEFAULT 'employee'::character varying,
    salary numeric(10,2),
    date_of_joining date,
    status character varying(20) DEFAULT 'Active'::character varying,
    password character varying(255) NOT NULL,
    login_attempts integer DEFAULT 0,
    locked_until timestamp without time zone,
    last_login_ip character varying(45),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    last_login_at timestamp without time zone,
    CONSTRAINT employees_status_check CHECK (((status)::text = ANY ((ARRAY['Active'::character varying, 'On Leave'::character varying, 'Resigned'::character varying])::text[])))
);


ALTER TABLE public.employees OWNER TO postgres;

--
-- TOC entry 5298 (class 0 OID 0)
-- Dependencies: 223
-- Name: TABLE employees; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.employees IS 'Stores employee information with tenant isolation and role-based access';


--
-- TOC entry 222 (class 1259 OID 16425)
-- Name: employees_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.employees_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.employees_id_seq OWNER TO postgres;

--
-- TOC entry 5299 (class 0 OID 0)
-- Dependencies: 222
-- Name: employees_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.employees_id_seq OWNED BY public.employees.id;


--
-- TOC entry 225 (class 1259 OID 16457)
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.inventory_items (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    item_name character varying(100) NOT NULL,
    item_code character varying(50) NOT NULL,
    category character varying(50),
    stock_qty integer DEFAULT 0,
    purchase_price numeric(10,2),
    selling_price numeric(10,2),
    reorder_level integer DEFAULT 10,
    supplier_name character varying(100),
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.inventory_items OWNER TO postgres;

--
-- TOC entry 5300 (class 0 OID 0)
-- Dependencies: 225
-- Name: TABLE inventory_items; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.inventory_items IS 'Stores inventory items with tenant isolation';


--
-- TOC entry 224 (class 1259 OID 16456)
-- Name: inventory_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.inventory_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.inventory_items_id_seq OWNER TO postgres;

--
-- TOC entry 5301 (class 0 OID 0)
-- Dependencies: 224
-- Name: inventory_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.inventory_items_id_seq OWNED BY public.inventory_items.id;


--
-- TOC entry 221 (class 1259 OID 16401)
-- Name: tenants; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.tenants (
    tenant_id integer NOT NULL,
    business_name character varying(150) NOT NULL,
    owner_first_name character varying(100) NOT NULL,
    owner_last_name character varying(100) NOT NULL,
    owner_email character varying(150) NOT NULL,
    owner_password character varying(255) NOT NULL,
    tagline character varying(255),
    contact_address text,
    phone character varying(20),
    is_active boolean DEFAULT true,
    subscription_plan character varying(50) DEFAULT 'basic'::character varying,
    subscription_status character varying(20) DEFAULT 'active'::character varying,
    trial_ends_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    login_attempts integer DEFAULT 0,
    locked_until timestamp without time zone,
    last_login_ip character varying(45),
    last_login_at timestamp without time zone
);


ALTER TABLE public.tenants OWNER TO postgres;

--
-- TOC entry 5302 (class 0 OID 0)
-- Dependencies: 221
-- Name: TABLE tenants; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.tenants IS 'Stores business owner/tenant information for multi-tenant isolation';


--
-- TOC entry 244 (class 1259 OID 16750)
-- Name: low_stock_items; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.low_stock_items AS
 SELECT i.tenant_id,
    i.id,
    i.item_name,
    i.item_code,
    i.category,
    i.stock_qty,
    i.reorder_level,
    i.selling_price,
    t.business_name
   FROM (public.inventory_items i
     JOIN public.tenants t ON ((i.tenant_id = t.tenant_id)))
  WHERE (i.stock_qty <= i.reorder_level)
  ORDER BY i.tenant_id, i.stock_qty;


ALTER VIEW public.low_stock_items OWNER TO postgres;

--
-- TOC entry 5303 (class 0 OID 0)
-- Dependencies: 244
-- Name: VIEW low_stock_items; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.low_stock_items IS 'Shows items with stock below reorder level';


--
-- TOC entry 235 (class 1259 OID 16629)
-- Name: maintenance_expenses; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.maintenance_expenses (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    entry_date date NOT NULL,
    expense_type character varying(50),
    brief text,
    amount numeric(10,2),
    payment_method character varying(20),
    invoice_number character varying(50),
    vendor_name character varying(100),
    recorded_by integer,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT maintenance_expenses_payment_method_check CHECK (((payment_method)::text = ANY ((ARRAY['Cash'::character varying, 'UPI'::character varying, 'Credit'::character varying, 'Debit'::character varying, 'Card'::character varying, 'Bank Transfer'::character varying])::text[])))
);


ALTER TABLE public.maintenance_expenses OWNER TO postgres;

--
-- TOC entry 5304 (class 0 OID 0)
-- Dependencies: 235
-- Name: TABLE maintenance_expenses; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.maintenance_expenses IS 'Stores maintenance and operational expenses with tenant isolation';


--
-- TOC entry 234 (class 1259 OID 16628)
-- Name: maintenance_expenses_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.maintenance_expenses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.maintenance_expenses_id_seq OWNER TO postgres;

--
-- TOC entry 5305 (class 0 OID 0)
-- Dependencies: 234
-- Name: maintenance_expenses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.maintenance_expenses_id_seq OWNED BY public.maintenance_expenses.id;


--
-- TOC entry 233 (class 1259 OID 16588)
-- Name: salary_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salary_details (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    employee_id integer NOT NULL,
    month_year character varying(7) NOT NULL,
    base_salary numeric(10,2),
    bonus numeric(10,2) DEFAULT 0.00,
    deductions numeric(10,2) DEFAULT 0.00,
    leave_deduction numeric(10,2) DEFAULT 0.00,
    net_salary numeric(10,2),
    final_salary numeric(10,2),
    payment_date date,
    payment_status character varying(20) DEFAULT 'pending'::character varying,
    paid_by integer,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT salary_details_payment_status_check CHECK (((payment_status)::text = ANY ((ARRAY['pending'::character varying, 'paid'::character varying, 'cancelled'::character varying])::text[])))
);


ALTER TABLE public.salary_details OWNER TO postgres;

--
-- TOC entry 5306 (class 0 OID 0)
-- Dependencies: 233
-- Name: TABLE salary_details; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.salary_details IS 'Stores employee salary details with tenant isolation';


--
-- TOC entry 232 (class 1259 OID 16587)
-- Name: salary_details_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.salary_details_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.salary_details_id_seq OWNER TO postgres;

--
-- TOC entry 5307 (class 0 OID 0)
-- Dependencies: 232
-- Name: salary_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.salary_details_id_seq OWNED BY public.salary_details.id;


--
-- TOC entry 245 (class 1259 OID 16762)
-- Name: session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.session (
    sid character varying NOT NULL,
    sess json NOT NULL,
    expire timestamp(6) without time zone NOT NULL
);


ALTER TABLE public.session OWNER TO postgres;

--
-- TOC entry 240 (class 1259 OID 16705)
-- Name: sessions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sessions (
    session_id character varying(128) NOT NULL,
    expires bigint NOT NULL,
    data text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.sessions OWNER TO postgres;

--
-- TOC entry 5308 (class 0 OID 0)
-- Dependencies: 240
-- Name: TABLE sessions; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.sessions IS 'Stores session data for authentication';


--
-- TOC entry 237 (class 1259 OID 16657)
-- Name: supplier_khata; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.supplier_khata (
    id integer NOT NULL,
    tenant_id integer NOT NULL,
    entry_date date NOT NULL,
    supplier_name character varying(100),
    phone_number character varying(15),
    amount numeric(10,2),
    due_date date,
    khata_cycle integer,
    payment_status character varying(20) DEFAULT 'pending'::character varying,
    paid_amount numeric(10,2) DEFAULT 0.00,
    notes text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT supplier_khata_payment_status_check CHECK (((payment_status)::text = ANY ((ARRAY['pending'::character varying, 'partial'::character varying, 'paid'::character varying])::text[])))
);


ALTER TABLE public.supplier_khata OWNER TO postgres;

--
-- TOC entry 5309 (class 0 OID 0)
-- Dependencies: 237
-- Name: TABLE supplier_khata; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.supplier_khata IS 'Stores supplier credit accounts with tenant isolation';


--
-- TOC entry 236 (class 1259 OID 16656)
-- Name: supplier_khata_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.supplier_khata_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.supplier_khata_id_seq OWNER TO postgres;

--
-- TOC entry 5310 (class 0 OID 0)
-- Dependencies: 236
-- Name: supplier_khata_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.supplier_khata_id_seq OWNED BY public.supplier_khata.id;


--
-- TOC entry 243 (class 1259 OID 16745)
-- Name: tenant_dashboard_summary; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.tenant_dashboard_summary AS
 SELECT t.tenant_id,
    t.business_name,
    count(DISTINCT e.id) AS total_employees,
    count(DISTINCT i.id) AS total_inventory_items,
    sum(((i.stock_qty)::numeric * i.selling_price)) AS total_inventory_value,
    count(DISTINCT b.bill_id) AS total_bills,
    sum(b.grand_total) AS total_revenue,
    count(DISTINCT b.bill_id) FILTER (WHERE (b.bill_date >= (CURRENT_DATE - '30 days'::interval))) AS bills_last_30_days,
    sum(b.grand_total) FILTER (WHERE (b.bill_date >= (CURRENT_DATE - '30 days'::interval))) AS revenue_last_30_days
   FROM (((public.tenants t
     LEFT JOIN public.employees e ON (((t.tenant_id = e.tenant_id) AND ((e.status)::text = 'Active'::text))))
     LEFT JOIN public.inventory_items i ON ((t.tenant_id = i.tenant_id)))
     LEFT JOIN public.bills b ON ((t.tenant_id = b.tenant_id)))
  WHERE (t.is_active = true)
  GROUP BY t.tenant_id, t.business_name;


ALTER VIEW public.tenant_dashboard_summary OWNER TO postgres;

--
-- TOC entry 5311 (class 0 OID 0)
-- Dependencies: 243
-- Name: VIEW tenant_dashboard_summary; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON VIEW public.tenant_dashboard_summary IS 'Provides summary statistics for tenant dashboard';


--
-- TOC entry 220 (class 1259 OID 16400)
-- Name: tenants_tenant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.tenants_tenant_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tenants_tenant_id_seq OWNER TO postgres;

--
-- TOC entry 5312 (class 0 OID 0)
-- Dependencies: 220
-- Name: tenants_tenant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.tenants_tenant_id_seq OWNED BY public.tenants.tenant_id;


--
-- TOC entry 242 (class 1259 OID 16717)
-- Name: user_details; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_details (
    id integer NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    email character varying(150) NOT NULL,
    password character varying(255) NOT NULL,
    business_name character varying(150),
    tagline character varying(255),
    contact_address text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true,
    login_attempts integer DEFAULT 0,
    locked_until timestamp without time zone,
    last_login_ip character varying(45),
    last_login_at timestamp without time zone
);


ALTER TABLE public.user_details OWNER TO postgres;

--
-- TOC entry 5313 (class 0 OID 0)
-- Dependencies: 242
-- Name: TABLE user_details; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON TABLE public.user_details IS 'Legacy table - use tenants table instead';


--
-- TOC entry 241 (class 1259 OID 16716)
-- Name: user_details_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.user_details_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.user_details_id_seq OWNER TO postgres;

--
-- TOC entry 5314 (class 0 OID 0)
-- Dependencies: 241
-- Name: user_details_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.user_details_id_seq OWNED BY public.user_details.id;


--
-- TOC entry 4961 (class 2604 OID 16553)
-- Name: attendance_leaves id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_leaves ALTER COLUMN id SET DEFAULT nextval('public.attendance_leaves_id_seq'::regclass);


--
-- TOC entry 4980 (class 2604 OID 16686)
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- TOC entry 4959 (class 2604 OID 16519)
-- Name: bill_items item_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_items ALTER COLUMN item_id SET DEFAULT nextval('public.bill_items_item_id_seq'::regclass);


--
-- TOC entry 4954 (class 2604 OID 16486)
-- Name: bills bill_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bills ALTER COLUMN bill_id SET DEFAULT nextval('public.bills_bill_id_seq'::regclass);


--
-- TOC entry 4943 (class 2604 OID 16429)
-- Name: employees id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees ALTER COLUMN id SET DEFAULT nextval('public.employees_id_seq'::regclass);


--
-- TOC entry 4949 (class 2604 OID 16460)
-- Name: inventory_items id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_items ALTER COLUMN id SET DEFAULT nextval('public.inventory_items_id_seq'::regclass);


--
-- TOC entry 4972 (class 2604 OID 16632)
-- Name: maintenance_expenses id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maintenance_expenses ALTER COLUMN id SET DEFAULT nextval('public.maintenance_expenses_id_seq'::regclass);


--
-- TOC entry 4965 (class 2604 OID 16591)
-- Name: salary_details id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_details ALTER COLUMN id SET DEFAULT nextval('public.salary_details_id_seq'::regclass);


--
-- TOC entry 4975 (class 2604 OID 16660)
-- Name: supplier_khata id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_khata ALTER COLUMN id SET DEFAULT nextval('public.supplier_khata_id_seq'::regclass);


--
-- TOC entry 4936 (class 2604 OID 16404)
-- Name: tenants tenant_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants ALTER COLUMN tenant_id SET DEFAULT nextval('public.tenants_tenant_id_seq'::regclass);


--
-- TOC entry 4983 (class 2604 OID 16720)
-- Name: user_details id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_details ALTER COLUMN id SET DEFAULT nextval('public.user_details_id_seq'::regclass);


--
-- TOC entry 5271 (class 0 OID 16550)
-- Dependencies: 231
-- Data for Name: attendance_leaves; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.attendance_leaves (id, tenant_id, employee_id, date, status, leave_type, reason, approved_by, created_at, updated_at) FROM stdin;
1	1	4	2025-11-02	Present	\N	\N	\N	2025-11-02 23:53:25.590498	2025-11-02 23:53:25.590498
2	2	8	2025-11-03	Present	\N	\N	\N	2025-11-03 13:00:07.524644	2025-11-03 13:00:07.524644
3	2	7	2025-11-03	Present	\N	\N	\N	2025-11-03 13:00:08.65054	2025-11-03 13:00:08.65054
4	2	6	2025-11-03	Leave	sick	bhnj	\N	2025-11-03 13:00:16.833816	2025-11-03 13:00:16.833816
5	2	9	2025-11-03	Absent	unpaid	bhjk	\N	2025-11-03 13:00:27.083728	2025-11-03 13:00:27.083728
6	2	5	2025-11-03	Present	\N	\N	\N	2025-11-03 13:00:28.818499	2025-11-03 13:00:28.818499
\.


--
-- TOC entry 5279 (class 0 OID 16683)
-- Dependencies: 239
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.audit_log (id, tenant_id, event_type, user_id, user_type, ip_address, user_agent, details, created_at) FROM stdin;
\.


--
-- TOC entry 5269 (class 0 OID 16516)
-- Dependencies: 229
-- Data for Name: bill_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bill_items (item_id, tenant_id, bill_id, item_code, item_name, item_price, quantity, total, created_at) FROM stdin;
1	1	1	4110	Air Freshener 	255.00	1	255.00	2025-11-02 13:32:55.936614
2	2	2	1532	Air Freshener 	330.00	1	330.00	2025-11-03 11:52:29.064483
3	2	3	1532	Air Freshener 	330.00	1	330.00	2025-11-03 11:54:51.796061
4	2	4	1532	Air Freshener 	330.00	1	330.00	2025-11-03 12:20:50.192246
5	2	5	1532	Air Freshener 	330.00	1	330.00	2025-11-03 15:29:08.448799
\.


--
-- TOC entry 5267 (class 0 OID 16483)
-- Dependencies: 227
-- Data for Name: bills; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.bills (bill_id, tenant_id, bill_date, customer_name, customer_phone, customer_age_group, subtotal, gst, discount, grand_total, payment_method, created_by, created_at, updated_at) FROM stdin;
1	1	2025-11-02 08:02:55	azdf	2147896325	adult	255.00	45.90	0.00	300.90	Cash	\N	2025-11-02 13:32:55.936614	2025-11-02 13:32:55.936614
2	2	2025-11-03 06:22:29	sameer	1563256325	adult	330.00	59.40	0.00	389.40	Cash	\N	2025-11-03 11:52:29.064483	2025-11-03 11:52:29.064483
3	2	2025-11-03 06:24:51	sameer	1456321456	adult	330.00	59.40	0.00	389.40	Cash	\N	2025-11-03 11:54:51.796061	2025-11-03 11:54:51.796061
4	2	2025-11-03 06:50:50	sameer	1478621478	teen	330.00	59.40	0.00	389.40	Cash	\N	2025-11-03 12:20:50.192246	2025-11-03 12:20:50.192246
5	2	2025-11-03 09:59:08	sbdgh	5214214521	kid	330.00	59.40	0.00	389.40	Cash	\N	2025-11-03 15:29:08.448799	2025-11-03 15:29:08.448799
\.


--
-- TOC entry 5263 (class 0 OID 16426)
-- Dependencies: 223
-- Data for Name: employees; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.employees (id, tenant_id, name, email, phone, department, role, salary, date_of_joining, status, password, login_attempts, locked_until, last_login_ip, created_at, updated_at, last_login_at) FROM stdin;
5	2	test_beta	admin@bms.com	09392274862	Sales	employee	18000.00	2025-11-02	Active	$2b$12$CJ2X2j/7VcMNAWkoclMkQ.WW87T1gLB4Veryl3MJhgBvUG2k4ede.	0	\N	\N	2025-11-03 12:57:15.506227	2025-11-03 12:57:15.506227	\N
6	2	alpha	alpha@bms.com	95321586000	HR	employee	99999.00	2025-11-03	Active	$2b$12$wJiNLiObual.013ZwfVR3OBfGg10e9/rhRP1U6RRLw4FvbMB7CrYu	0	\N	\N	2025-11-03 12:57:59.991962	2025-11-03 12:57:59.991962	\N
7	2	gama	gama@bms.com	462145852	Finance	employee	25638.00	2025-11-03	Active	$2b$12$Hi1sj1mPVzf.10G1XgAQWOJHLluoD5/uxI/Vu24fU5KH/TXwZg1wq	0	\N	\N	2025-11-03 12:58:37.649653	2025-11-03 12:58:37.649653	\N
9	2	puto	puto@bms.com	1452145214	Inventory	employee	4521.00	2025-11-03	Active	$2b$12$FIYM6QcGES69rYYFRSMLFuSkEpK7qmNevkx9qtjzdpN/GrlZWPerW	0	\N	\N	2025-11-03 12:59:58.912121	2025-11-03 13:01:14.31325	\N
8	2	kuta	kuta@bms.com	1456321	Billing	employee	2563256.00	2025-11-03	Active	$2b$12$Xv472nbiZsbT5bLP7lmBDOUJqid9zhHMB/AtK3nycBgoS9pmLjzQ6	0	\N	\N	2025-11-03 12:59:18.396029	2025-11-03 13:01:28.871308	\N
4	1	test_beta	admin@bms.com	09392274862	Finance	employee	18000.00	2025-11-02	Active	$2b$12$JuVxQuNbgwVL4xXCpyPr1.FCxMNzi1zl4xx5PcOuWvDPD6KPpQZRK	0	\N	::1	2025-11-02 23:52:52.915306	2025-11-03 14:37:38.7159	2025-11-03 14:37:38.7159
\.


--
-- TOC entry 5265 (class 0 OID 16457)
-- Dependencies: 225
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.inventory_items (id, tenant_id, item_name, item_code, category, stock_qty, purchase_price, selling_price, reorder_level, supplier_name, created_at, updated_at) FROM stdin;
3	1	Air Freshener 	4110	Grocery	9	100.00	255.00	10	\N	2025-11-02 13:32:07.446416	2025-11-02 13:32:55.914862
4	2	Air Freshener 	1532	Grocery	2	220.00	330.00	10	\N	2025-11-03 11:51:57.439938	2025-11-03 15:29:08.438284
\.


--
-- TOC entry 5275 (class 0 OID 16629)
-- Dependencies: 235
-- Data for Name: maintenance_expenses; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.maintenance_expenses (id, tenant_id, entry_date, expense_type, brief, amount, payment_method, invoice_number, vendor_name, recorded_by, created_at, updated_at) FROM stdin;
1	1	2025-11-02	Maintenance	ac	1500.00	\N	\N	\N	\N	2025-11-02 23:54:55.830614	2025-11-02 23:54:55.830614
\.


--
-- TOC entry 5273 (class 0 OID 16588)
-- Dependencies: 233
-- Data for Name: salary_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salary_details (id, tenant_id, employee_id, month_year, base_salary, bonus, deductions, leave_deduction, net_salary, final_salary, payment_date, payment_status, paid_by, notes, created_at, updated_at) FROM stdin;
1	1	4	2025-11	18000.00	0.00	0.00	0.00	18000.00	18000.00	2025-11-02	paid	\N	\N	2025-11-02 23:52:52.932393	2025-11-02 23:53:46.226812
2	2	5	2025-11	18000.00	0.00	0.00	0.00	18000.00	18000.00	\N	pending	\N	\N	2025-11-03 12:57:15.512702	2025-11-03 12:57:15.512702
3	2	6	2025-11	99999.00	0.00	0.00	0.00	99999.00	99999.00	\N	pending	\N	\N	2025-11-03 12:58:00.000356	2025-11-03 12:58:00.000356
4	2	7	2025-11	25638.00	0.00	0.00	0.00	25638.00	25638.00	\N	pending	\N	\N	2025-11-03 12:58:37.659979	2025-11-03 12:58:37.659979
5	2	8	2025-11	2563256.00	0.00	0.00	0.00	2563256.00	2563256.00	\N	pending	\N	\N	2025-11-03 12:59:18.400412	2025-11-03 12:59:18.400412
6	2	9	2025-11	4521.00	0.00	0.00	0.00	4521.00	4521.00	\N	pending	\N	\N	2025-11-03 12:59:58.916794	2025-11-03 12:59:58.916794
\.


--
-- TOC entry 5283 (class 0 OID 16762)
-- Dependencies: 245
-- Data for Name: session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.session (sid, sess, expire) FROM stdin;
JtcoO4Fgj2M61ZpzZRRqg9izbw-R_iH7	{"cookie":{"originalMaxAge":3600000,"expires":"2025-11-03T11:45:08.051Z","secure":false,"httpOnly":true,"path":"/","sameSite":"lax"},"user":{"id":2,"tenant_id":2,"name":"sameer ","email":"sameer@retailstore.com","business_name":"bajji_point","role":"owner","isOwner":true,"subscription_plan":"trial","subscription_status":"active"}}	2025-11-03 17:15:57
\.


--
-- TOC entry 5280 (class 0 OID 16705)
-- Dependencies: 240
-- Data for Name: sessions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sessions (session_id, expires, data, created_at) FROM stdin;
\.


--
-- TOC entry 5277 (class 0 OID 16657)
-- Dependencies: 237
-- Data for Name: supplier_khata; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.supplier_khata (id, tenant_id, entry_date, supplier_name, phone_number, amount, due_date, khata_cycle, payment_status, paid_amount, notes, created_at, updated_at) FROM stdin;
1	1	2025-11-02	kim suplier	9392272684	6000.00	2025-12-02	15	pending	0.00	\N	2025-11-02 22:04:47.601097	2025-11-02 22:04:47.601097
\.


--
-- TOC entry 5261 (class 0 OID 16401)
-- Dependencies: 221
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.tenants (tenant_id, business_name, owner_first_name, owner_last_name, owner_email, owner_password, tagline, contact_address, phone, is_active, subscription_plan, subscription_status, trial_ends_at, created_at, updated_at, login_attempts, locked_until, last_login_ip, last_login_at) FROM stdin;
1	Demo Business	Admin	User	admin@demo.com	$2b$10$example.hash.for.password123	Your Trusted Business Partner	123 Main Street, City, State	1234567890	t	premium	active	\N	2025-11-02 13:29:04.90705	2025-11-02 13:29:04.90705	0	\N	\N	\N
2	bajji_point	sameer		sameer@retailstore.com	$2b$12$AMbyIWcXFCkdSoShekiUE.uy6smiRaxaDCle12vef1h5lAXDBDZSu	eat bujji and chill	vadodra,gujart,india	8008582733	t	trial	active	2025-12-03 11:02:08.661	2025-11-03 11:02:08.663518	2025-11-03 16:15:08.048487	0	\N	::1	2025-11-03 16:15:08.048487
\.


--
-- TOC entry 5282 (class 0 OID 16717)
-- Dependencies: 242
-- Data for Name: user_details; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_details (id, first_name, last_name, email, password, business_name, tagline, contact_address, created_at, active, login_attempts, locked_until, last_login_ip, last_login_at) FROM stdin;
\.


--
-- TOC entry 5315 (class 0 OID 0)
-- Dependencies: 230
-- Name: attendance_leaves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.attendance_leaves_id_seq', 6, true);


--
-- TOC entry 5316 (class 0 OID 0)
-- Dependencies: 238
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 1, false);


--
-- TOC entry 5317 (class 0 OID 0)
-- Dependencies: 228
-- Name: bill_items_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bill_items_item_id_seq', 5, true);


--
-- TOC entry 5318 (class 0 OID 0)
-- Dependencies: 226
-- Name: bills_bill_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.bills_bill_id_seq', 5, true);


--
-- TOC entry 5319 (class 0 OID 0)
-- Dependencies: 222
-- Name: employees_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.employees_id_seq', 9, true);


--
-- TOC entry 5320 (class 0 OID 0)
-- Dependencies: 224
-- Name: inventory_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.inventory_items_id_seq', 4, true);


--
-- TOC entry 5321 (class 0 OID 0)
-- Dependencies: 234
-- Name: maintenance_expenses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.maintenance_expenses_id_seq', 1, true);


--
-- TOC entry 5322 (class 0 OID 0)
-- Dependencies: 232
-- Name: salary_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.salary_details_id_seq', 6, true);


--
-- TOC entry 5323 (class 0 OID 0)
-- Dependencies: 236
-- Name: supplier_khata_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.supplier_khata_id_seq', 1, true);


--
-- TOC entry 5324 (class 0 OID 0)
-- Dependencies: 220
-- Name: tenants_tenant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.tenants_tenant_id_seq', 2, true);


--
-- TOC entry 5325 (class 0 OID 0)
-- Dependencies: 241
-- Name: user_details_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.user_details_id_seq', 1, false);


--
-- TOC entry 5033 (class 2606 OID 16565)
-- Name: attendance_leaves attendance_leaves_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_leaves
    ADD CONSTRAINT attendance_leaves_pkey PRIMARY KEY (id);


--
-- TOC entry 5035 (class 2606 OID 16567)
-- Name: attendance_leaves attendance_leaves_tenant_id_employee_id_date_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_leaves
    ADD CONSTRAINT attendance_leaves_tenant_id_employee_id_date_key UNIQUE (tenant_id, employee_id, date);


--
-- TOC entry 5060 (class 2606 OID 16694)
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 5027 (class 2606 OID 16530)
-- Name: bill_items bill_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_pkey PRIMARY KEY (item_id);


--
-- TOC entry 5020 (class 2606 OID 16500)
-- Name: bills bills_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_pkey PRIMARY KEY (bill_id);


--
-- TOC entry 5002 (class 2606 OID 16444)
-- Name: employees employees_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_pkey PRIMARY KEY (id);


--
-- TOC entry 5004 (class 2606 OID 16446)
-- Name: employees employees_tenant_id_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- TOC entry 5016 (class 2606 OID 16470)
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- TOC entry 5018 (class 2606 OID 16472)
-- Name: inventory_items inventory_items_tenant_id_item_code_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_tenant_id_item_code_key UNIQUE (tenant_id, item_code);


--
-- TOC entry 5052 (class 2606 OID 16642)
-- Name: maintenance_expenses maintenance_expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maintenance_expenses
    ADD CONSTRAINT maintenance_expenses_pkey PRIMARY KEY (id);


--
-- TOC entry 5045 (class 2606 OID 16606)
-- Name: salary_details salary_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_details
    ADD CONSTRAINT salary_details_pkey PRIMARY KEY (id);


--
-- TOC entry 5047 (class 2606 OID 16608)
-- Name: salary_details salary_details_tenant_id_employee_id_month_year_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_details
    ADD CONSTRAINT salary_details_tenant_id_employee_id_month_year_key UNIQUE (tenant_id, employee_id, month_year);


--
-- TOC entry 5076 (class 2606 OID 16771)
-- Name: session session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.session
    ADD CONSTRAINT session_pkey PRIMARY KEY (sid);


--
-- TOC entry 5068 (class 2606 OID 16714)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (session_id);


--
-- TOC entry 5058 (class 2606 OID 16672)
-- Name: supplier_khata supplier_khata_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_khata
    ADD CONSTRAINT supplier_khata_pkey PRIMARY KEY (id);


--
-- TOC entry 4998 (class 2606 OID 16422)
-- Name: tenants tenants_owner_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_owner_email_key UNIQUE (owner_email);


--
-- TOC entry 5000 (class 2606 OID 16420)
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (tenant_id);


--
-- TOC entry 5071 (class 2606 OID 16734)
-- Name: user_details user_details_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_details
    ADD CONSTRAINT user_details_email_key UNIQUE (email);


--
-- TOC entry 5073 (class 2606 OID 16732)
-- Name: user_details user_details_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_details
    ADD CONSTRAINT user_details_pkey PRIMARY KEY (id);


--
-- TOC entry 5074 (class 1259 OID 16772)
-- Name: IDX_session_expire; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "IDX_session_expire" ON public.session USING btree (expire);


--
-- TOC entry 5036 (class 1259 OID 16585)
-- Name: idx_attendance_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendance_date ON public.attendance_leaves USING btree (date);


--
-- TOC entry 5037 (class 1259 OID 16584)
-- Name: idx_attendance_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendance_employee ON public.attendance_leaves USING btree (employee_id);


--
-- TOC entry 5038 (class 1259 OID 16586)
-- Name: idx_attendance_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendance_status ON public.attendance_leaves USING btree (status);


--
-- TOC entry 5039 (class 1259 OID 16583)
-- Name: idx_attendance_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_attendance_tenant ON public.attendance_leaves USING btree (tenant_id);


--
-- TOC entry 5061 (class 1259 OID 16703)
-- Name: idx_audit_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_created ON public.audit_log USING btree (created_at);


--
-- TOC entry 5062 (class 1259 OID 16704)
-- Name: idx_audit_details; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_details ON public.audit_log USING gin (details);


--
-- TOC entry 5063 (class 1259 OID 16701)
-- Name: idx_audit_event; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_event ON public.audit_log USING btree (event_type);


--
-- TOC entry 5064 (class 1259 OID 16700)
-- Name: idx_audit_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_tenant ON public.audit_log USING btree (tenant_id);


--
-- TOC entry 5065 (class 1259 OID 16702)
-- Name: idx_audit_user; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_audit_user ON public.audit_log USING btree (user_id, user_type);


--
-- TOC entry 5028 (class 1259 OID 16547)
-- Name: idx_bill_items_bill; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bill_items_bill ON public.bill_items USING btree (bill_id);


--
-- TOC entry 5029 (class 1259 OID 16548)
-- Name: idx_bill_items_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bill_items_code ON public.bill_items USING btree (item_code);


--
-- TOC entry 5030 (class 1259 OID 16546)
-- Name: idx_bill_items_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bill_items_tenant ON public.bill_items USING btree (tenant_id);


--
-- TOC entry 5031 (class 1259 OID 16758)
-- Name: idx_bill_items_tenant_bill; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bill_items_tenant_bill ON public.bill_items USING btree (tenant_id, bill_id);


--
-- TOC entry 5021 (class 1259 OID 16513)
-- Name: idx_bills_customer; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bills_customer ON public.bills USING btree (customer_phone);


--
-- TOC entry 5022 (class 1259 OID 16512)
-- Name: idx_bills_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bills_date ON public.bills USING btree (bill_date);


--
-- TOC entry 5023 (class 1259 OID 16514)
-- Name: idx_bills_payment; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bills_payment ON public.bills USING btree (payment_method);


--
-- TOC entry 5024 (class 1259 OID 16511)
-- Name: idx_bills_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bills_tenant ON public.bills USING btree (tenant_id);


--
-- TOC entry 5025 (class 1259 OID 16755)
-- Name: idx_bills_tenant_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_bills_tenant_date ON public.bills USING btree (tenant_id, bill_date DESC);


--
-- TOC entry 5005 (class 1259 OID 16453)
-- Name: idx_employees_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_email ON public.employees USING btree (email);


--
-- TOC entry 5006 (class 1259 OID 16455)
-- Name: idx_employees_role; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_role ON public.employees USING btree (role);


--
-- TOC entry 5007 (class 1259 OID 16454)
-- Name: idx_employees_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_status ON public.employees USING btree (status);


--
-- TOC entry 5008 (class 1259 OID 16452)
-- Name: idx_employees_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_tenant ON public.employees USING btree (tenant_id);


--
-- TOC entry 5009 (class 1259 OID 16756)
-- Name: idx_employees_tenant_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_employees_tenant_status ON public.employees USING btree (tenant_id, status);


--
-- TOC entry 5010 (class 1259 OID 16480)
-- Name: idx_inventory_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_category ON public.inventory_items USING btree (category);


--
-- TOC entry 5011 (class 1259 OID 16479)
-- Name: idx_inventory_code; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_code ON public.inventory_items USING btree (item_code);


--
-- TOC entry 5012 (class 1259 OID 16481)
-- Name: idx_inventory_stock; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_stock ON public.inventory_items USING btree (stock_qty);


--
-- TOC entry 5013 (class 1259 OID 16478)
-- Name: idx_inventory_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_tenant ON public.inventory_items USING btree (tenant_id);


--
-- TOC entry 5014 (class 1259 OID 16757)
-- Name: idx_inventory_tenant_category; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_inventory_tenant_category ON public.inventory_items USING btree (tenant_id, category);


--
-- TOC entry 5048 (class 1259 OID 16654)
-- Name: idx_maintenance_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_maintenance_date ON public.maintenance_expenses USING btree (entry_date);


--
-- TOC entry 5049 (class 1259 OID 16653)
-- Name: idx_maintenance_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_maintenance_tenant ON public.maintenance_expenses USING btree (tenant_id);


--
-- TOC entry 5050 (class 1259 OID 16655)
-- Name: idx_maintenance_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_maintenance_type ON public.maintenance_expenses USING btree (expense_type);


--
-- TOC entry 5040 (class 1259 OID 16625)
-- Name: idx_salary_employee; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_salary_employee ON public.salary_details USING btree (employee_id);


--
-- TOC entry 5041 (class 1259 OID 16626)
-- Name: idx_salary_month; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_salary_month ON public.salary_details USING btree (month_year);


--
-- TOC entry 5042 (class 1259 OID 16627)
-- Name: idx_salary_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_salary_status ON public.salary_details USING btree (payment_status);


--
-- TOC entry 5043 (class 1259 OID 16624)
-- Name: idx_salary_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_salary_tenant ON public.salary_details USING btree (tenant_id);


--
-- TOC entry 5066 (class 1259 OID 16715)
-- Name: idx_sessions_expires; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_sessions_expires ON public.sessions USING btree (expires);


--
-- TOC entry 5053 (class 1259 OID 16680)
-- Name: idx_supplier_due_date; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_supplier_due_date ON public.supplier_khata USING btree (due_date);


--
-- TOC entry 5054 (class 1259 OID 16679)
-- Name: idx_supplier_name; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_supplier_name ON public.supplier_khata USING btree (supplier_name);


--
-- TOC entry 5055 (class 1259 OID 16681)
-- Name: idx_supplier_status; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_supplier_status ON public.supplier_khata USING btree (payment_status);


--
-- TOC entry 5056 (class 1259 OID 16678)
-- Name: idx_supplier_tenant; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_supplier_tenant ON public.supplier_khata USING btree (tenant_id);


--
-- TOC entry 4995 (class 1259 OID 16424)
-- Name: idx_tenants_active; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tenants_active ON public.tenants USING btree (is_active);


--
-- TOC entry 4996 (class 1259 OID 16423)
-- Name: idx_tenants_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_tenants_email ON public.tenants USING btree (owner_email);


--
-- TOC entry 5069 (class 1259 OID 16735)
-- Name: idx_user_details_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_user_details_email ON public.user_details USING btree (email);


--
-- TOC entry 5098 (class 2620 OID 16741)
-- Name: attendance_leaves update_attendance_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_attendance_updated_at BEFORE UPDATE ON public.attendance_leaves FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 5097 (class 2620 OID 16740)
-- Name: bills update_bills_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_bills_updated_at BEFORE UPDATE ON public.bills FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 5095 (class 2620 OID 16738)
-- Name: employees update_employees_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_employees_updated_at BEFORE UPDATE ON public.employees FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 5096 (class 2620 OID 16739)
-- Name: inventory_items update_inventory_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_inventory_updated_at BEFORE UPDATE ON public.inventory_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 5100 (class 2620 OID 16743)
-- Name: maintenance_expenses update_maintenance_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_maintenance_updated_at BEFORE UPDATE ON public.maintenance_expenses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 5099 (class 2620 OID 16742)
-- Name: salary_details update_salary_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_salary_updated_at BEFORE UPDATE ON public.salary_details FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 5101 (class 2620 OID 16744)
-- Name: supplier_khata update_supplier_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_supplier_updated_at BEFORE UPDATE ON public.supplier_khata FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 5094 (class 2620 OID 16737)
-- Name: tenants update_tenants_updated_at; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER update_tenants_updated_at BEFORE UPDATE ON public.tenants FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 5084 (class 2606 OID 16578)
-- Name: attendance_leaves attendance_leaves_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_leaves
    ADD CONSTRAINT attendance_leaves_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.employees(id);


--
-- TOC entry 5085 (class 2606 OID 16573)
-- Name: attendance_leaves attendance_leaves_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_leaves
    ADD CONSTRAINT attendance_leaves_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- TOC entry 5086 (class 2606 OID 16568)
-- Name: attendance_leaves attendance_leaves_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.attendance_leaves
    ADD CONSTRAINT attendance_leaves_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- TOC entry 5093 (class 2606 OID 16695)
-- Name: audit_log audit_log_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- TOC entry 5081 (class 2606 OID 16536)
-- Name: bill_items bill_items_bill_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_bill_id_fkey FOREIGN KEY (bill_id) REFERENCES public.bills(bill_id) ON DELETE CASCADE;


--
-- TOC entry 5082 (class 2606 OID 16531)
-- Name: bill_items bill_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- TOC entry 5083 (class 2606 OID 16541)
-- Name: bill_items bill_items_tenant_id_item_code_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bill_items
    ADD CONSTRAINT bill_items_tenant_id_item_code_fkey FOREIGN KEY (tenant_id, item_code) REFERENCES public.inventory_items(tenant_id, item_code) ON DELETE RESTRICT;


--
-- TOC entry 5079 (class 2606 OID 16506)
-- Name: bills bills_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.employees(id);


--
-- TOC entry 5080 (class 2606 OID 16501)
-- Name: bills bills_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.bills
    ADD CONSTRAINT bills_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- TOC entry 5077 (class 2606 OID 16447)
-- Name: employees employees_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.employees
    ADD CONSTRAINT employees_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- TOC entry 5078 (class 2606 OID 16473)
-- Name: inventory_items inventory_items_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- TOC entry 5090 (class 2606 OID 16648)
-- Name: maintenance_expenses maintenance_expenses_recorded_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maintenance_expenses
    ADD CONSTRAINT maintenance_expenses_recorded_by_fkey FOREIGN KEY (recorded_by) REFERENCES public.employees(id);


--
-- TOC entry 5091 (class 2606 OID 16643)
-- Name: maintenance_expenses maintenance_expenses_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.maintenance_expenses
    ADD CONSTRAINT maintenance_expenses_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- TOC entry 5087 (class 2606 OID 16614)
-- Name: salary_details salary_details_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_details
    ADD CONSTRAINT salary_details_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.employees(id) ON DELETE CASCADE;


--
-- TOC entry 5088 (class 2606 OID 16619)
-- Name: salary_details salary_details_paid_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_details
    ADD CONSTRAINT salary_details_paid_by_fkey FOREIGN KEY (paid_by) REFERENCES public.employees(id);


--
-- TOC entry 5089 (class 2606 OID 16609)
-- Name: salary_details salary_details_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salary_details
    ADD CONSTRAINT salary_details_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- TOC entry 5092 (class 2606 OID 16673)
-- Name: supplier_khata supplier_khata_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.supplier_khata
    ADD CONSTRAINT supplier_khata_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(tenant_id) ON DELETE CASCADE;


--
-- TOC entry 5255 (class 0 OID 16550)
-- Dependencies: 231
-- Name: attendance_leaves; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.attendance_leaves ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 5259 (class 0 OID 16683)
-- Dependencies: 239
-- Name: audit_log; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.audit_log ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 5254 (class 0 OID 16516)
-- Dependencies: 229
-- Name: bill_items; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.bill_items ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 5253 (class 0 OID 16483)
-- Dependencies: 227
-- Name: bills; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.bills ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 5251 (class 0 OID 16426)
-- Dependencies: 223
-- Name: employees; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 5252 (class 0 OID 16457)
-- Dependencies: 225
-- Name: inventory_items; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.inventory_items ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 5257 (class 0 OID 16629)
-- Dependencies: 235
-- Name: maintenance_expenses; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.maintenance_expenses ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 5256 (class 0 OID 16588)
-- Dependencies: 233
-- Name: salary_details; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.salary_details ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 5258 (class 0 OID 16657)
-- Dependencies: 237
-- Name: supplier_khata; Type: ROW SECURITY; Schema: public; Owner: postgres
--

ALTER TABLE public.supplier_khata ENABLE ROW LEVEL SECURITY;

-- Completed on 2025-11-03 17:18:33

--
-- PostgreSQL database dump complete
--

\unrestrict Pabu7q0VYjHGBkN7scfqq0PYmvsmNukhchevPZ3KM12CkHEz3hcjHq61WCvFwkU

