const db = require('../models/mainModel');

/**
 * Tenant Management Utility
 * Helper functions for managing multi-tenant operations
 */

/**
 * Get tenant by ID
 * @param {number} tenantId - The tenant ID
 * @returns {Object} Tenant data
 */
async function getTenantById(tenantId) {
    const sql = `SELECT * FROM tenants WHERE id = $1 AND is_active = TRUE`;
    const result = await db.query(sql, [tenantId]);
    if (result.rows.length === 0) {
        throw new Error('Tenant not found or inactive');
    }
    return result.rows[0];
}

/**
 * Get tenant by code
 * @param {string} tenantCode - The tenant code
 * @returns {Object} Tenant data
 */
async function getTenantByCode(tenantCode) {
    const sql = `SELECT * FROM tenants WHERE tenant_code = $1 AND is_active = TRUE`;
    const result = await db.query(sql, [tenantCode]);
    if (result.rows.length === 0) {
        throw new Error('Tenant not found or inactive');
    }
    return result.rows[0];
}

/**
 * Create a new tenant
 * @param {Object} tenantData - Tenant information
 * @returns {Object} Created tenant
 */
async function createTenant(tenantData) {
    const {
        tenant_name,
        tenant_code,
        business_type,
        contact_email,
        contact_phone,
        address,
        settings = {}
    } = tenantData;

    // Check if tenant code already exists
    const existingCheck = await db.query(
        'SELECT id FROM tenants WHERE tenant_code = $1',
        [tenant_code]
    );

    if (existingCheck.rows.length > 0) {
        throw new Error('Tenant code already exists');
    }

    const sql = `
        INSERT INTO tenants 
        (tenant_name, tenant_code, business_type, contact_email, contact_phone, address, settings)
        VALUES ($1, $2, $3, $4, $5, $6, $7)
        RETURNING *
    `;

    const result = await db.query(sql, [
        tenant_name,
        tenant_code,
        business_type,
        contact_email,
        contact_phone,
        address,
        JSON.stringify(settings)
    ]);

    return result.rows[0];
}

/**
 * Update tenant information
 * @param {number} tenantId - The tenant ID
 * @param {Object} updates - Fields to update
 * @returns {Object} Updated tenant
 */
async function updateTenant(tenantId, updates) {
    const allowedFields = ['tenant_name', 'business_type', 'contact_email', 'contact_phone', 'address', 'settings', 'is_active'];
    const updateFields = [];
    const values = [];
    let paramCount = 0;

    for (const [key, value] of Object.entries(updates)) {
        if (allowedFields.includes(key)) {
            paramCount++;
            updateFields.push(`${key} = $${paramCount}`);
            values.push(key === 'settings' ? JSON.stringify(value) : value);
        }
    }

    if (updateFields.length === 0) {
        throw new Error('No valid fields to update');
    }

    paramCount++;
    values.push(tenantId);

    const sql = `
        UPDATE tenants 
        SET ${updateFields.join(', ')}, updated_at = CURRENT_TIMESTAMP
        WHERE id = $${paramCount}
        RETURNING *
    `;

    const result = await db.query(sql, values);
    if (result.rows.length === 0) {
        throw new Error('Tenant not found');
    }

    return result.rows[0];
}

/**
 * Deactivate a tenant (soft delete)
 * @param {number} tenantId - The tenant ID
 * @returns {Object} Updated tenant
 */
async function deactivateTenant(tenantId) {
    const sql = `
        UPDATE tenants 
        SET is_active = FALSE, updated_at = CURRENT_TIMESTAMP
        WHERE id = $1
        RETURNING *
    `;

    const result = await db.query(sql, [tenantId]);
    if (result.rows.length === 0) {
        throw new Error('Tenant not found');
    }

    return result.rows[0];
}

/**
 * Activate a tenant
 * @param {number} tenantId - The tenant ID
 * @returns {Object} Updated tenant
 */
async function activateTenant(tenantId) {
    const sql = `
        UPDATE tenants 
        SET is_active = TRUE, updated_at = CURRENT_TIMESTAMP
        WHERE id = $1
        RETURNING *
    `;

    const result = await db.query(sql, [tenantId]);
    if (result.rows.length === 0) {
        throw new Error('Tenant not found');
    }

    return result.rows[0];
}

/**
 * Get all tenants (with pagination)
 * @param {number} limit - Number of records per page
 * @param {number} offset - Offset for pagination
 * @param {boolean} includeInactive - Include inactive tenants
 * @returns {Array} List of tenants
 */
async function getAllTenants(limit = 50, offset = 0, includeInactive = false) {
    let sql = `SELECT * FROM tenants`;
    const params = [];

    if (!includeInactive) {
        sql += ` WHERE is_active = TRUE`;
    }

    sql += ` ORDER BY created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`;
    params.push(limit, offset);

    const result = await db.query(sql, params);
    return result.rows;
}

/**
 * Get tenant statistics
 * @param {number} tenantId - The tenant ID
 * @returns {Object} Tenant statistics
 */
async function getTenantStats(tenantId) {
    const client = await db.connect();
    try {
        // Get inventory count
        const inventoryResult = await client.query(
            'SELECT COUNT(*) as count FROM inventory_items WHERE tenant_id = $1',
            [tenantId]
        );

        // Get bills count and total revenue
        const billsResult = await client.query(
            'SELECT COUNT(*) as count, SUM(grand_total) as total_revenue FROM bills WHERE tenant_id = $1',
            [tenantId]
        );

        // Get categories count
        const categoriesResult = await client.query(
            'SELECT COUNT(*) as count FROM business_categories WHERE tenant_id = $1',
            [tenantId]
        );

        return {
            inventory_items: parseInt(inventoryResult.rows[0].count),
            total_bills: parseInt(billsResult.rows[0].count),
            total_revenue: parseFloat(billsResult.rows[0].total_revenue) || 0,
            custom_categories: parseInt(categoriesResult.rows[0].count)
        };
    } finally {
        client.release();
    }
}

/**
 * Delete tenant and all associated data (use with caution!)
 * @param {number} tenantId - The tenant ID
 * @param {boolean} confirm - Must be true to proceed
 * @returns {Object} Deletion result
 */
async function deleteTenant(tenantId, confirm = false) {
    if (!confirm) {
        throw new Error('Deletion must be confirmed. This action cannot be undone.');
    }

    // The CASCADE constraint will automatically delete related records
    const sql = `DELETE FROM tenants WHERE id = $1 RETURNING *`;
    const result = await db.query(sql, [tenantId]);

    if (result.rows.length === 0) {
        throw new Error('Tenant not found');
    }

    return {
        success: true,
        deleted_tenant: result.rows[0]
    };
}

/**
 * Get tenant settings
 * @param {number} tenantId - The tenant ID
 * @returns {Object} Tenant settings
 */
async function getTenantSettings(tenantId) {
    const sql = `SELECT settings FROM tenants WHERE id = $1`;
    const result = await db.query(sql, [tenantId]);

    if (result.rows.length === 0) {
        throw new Error('Tenant not found');
    }

    return result.rows[0].settings || {};
}

/**
 * Update tenant settings
 * @param {number} tenantId - The tenant ID
 * @param {Object} settings - New settings object
 * @returns {Object} Updated settings
 */
async function updateTenantSettings(tenantId, settings) {
    const sql = `
        UPDATE tenants 
        SET settings = $1, updated_at = CURRENT_TIMESTAMP
        WHERE id = $2
        RETURNING settings
    `;

    const result = await db.query(sql, [JSON.stringify(settings), tenantId]);

    if (result.rows.length === 0) {
        throw new Error('Tenant not found');
    }

    return result.rows[0].settings;
}

/**
 * Validate tenant access for a user
 * @param {number} userId - The user ID
 * @param {number} tenantId - The tenant ID
 * @returns {boolean} Whether user has access to tenant
 */
async function validateTenantAccess(userId, tenantId) {
    // This assumes you have a users table with tenant_id
    const sql = `
        SELECT id FROM users 
        WHERE id = $1 AND tenant_id = $2 AND is_active = TRUE
    `;

    const result = await db.query(sql, [userId, tenantId]);
    return result.rows.length > 0;
}

/**
 * Middleware function to extract and validate tenant from request
 * Use this in your Express routes
 */
function requireTenant(req, res, next) {
    if (!req.session || !req.session.user || !req.session.user.tenant_id) {
        return res.status(401).json({
            success: false,
            message: 'No tenant associated with user session'
        });
    }

    req.tenantId = req.session.user.tenant_id;
    next();
}

/**
 * Create default categories for a new tenant based on business type
 * @param {number} tenantId - The tenant ID
 * @param {string} businessType - Type of business
 * @returns {Array} Created categories
 */
async function createDefaultCategories(tenantId, businessType) {
    const categoryTemplates = {
        retail: ['Electronics', 'Clothing', 'Accessories', 'Home & Garden', 'Books'],
        restaurant: ['Appetizers', 'Main Course', 'Beverages', 'Desserts', 'Special Menu'],
        salon: ['Haircut', 'Hair Coloring', 'Styling', 'Spa Services', 'Nail Services'],
        clinic: ['Consultation', 'Diagnostics', 'Medicines', 'Procedures', 'Follow-up'],
        warehouse: ['Raw Materials', 'Finished Goods', 'Tools & Equipment', 'Packaging', 'Supplies'],
        general: ['General', 'Services', 'Products', 'Miscellaneous']
    };

    const categories = categoryTemplates[businessType] || categoryTemplates.general;
    const createdCategories = [];

    for (const category of categories) {
        const sql = `
            INSERT INTO business_categories (tenant_id, category_name, category_type, is_active)
            VALUES ($1, $2, 'inventory', TRUE)
            ON CONFLICT (tenant_id, category_name, category_type) DO NOTHING
            RETURNING *
        `;

        const result = await db.query(sql, [tenantId, category]);
        if (result.rows.length > 0) {
            createdCategories.push(result.rows[0]);
        }
    }

    return createdCategories;
}

module.exports = {
    getTenantById,
    getTenantByCode,
    createTenant,
    updateTenant,
    deactivateTenant,
    activateTenant,
    getAllTenants,
    getTenantStats,
    deleteTenant,
    getTenantSettings,
    updateTenantSettings,
    validateTenantAccess,
    requireTenant,
    createDefaultCategories
};
