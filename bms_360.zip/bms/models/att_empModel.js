const db = require('./mainModel');

const Attendance = {
    // Get all attendance records for a specific date with tenant isolation - Promise style
    getAttendanceByDate: async (date, tenantId) => {
        try {
            const result = await db.query(
                `SELECT a.*, e.name, e.department 
                 FROM attendance_leaves a
                 LEFT JOIN employees e ON a.employee_id = e.id AND a.tenant_id = e.tenant_id
                 WHERE DATE(a.date) = $1 AND a.tenant_id = $2
                 ORDER BY e.department, e.name
                 LIMIT 500`,  // Add limit to prevent excessive data loading
                [date, tenantId]
            );
            return result.rows;
        } catch (error) {
            throw error;
        }
    },

    // Add or update attendance record with tenant isolation - Promise style
    saveAttendance: async (data, tenantId) => {
        try {
            // Map the status values to match the database enum
            const statusMap = {
                'present': 'Present',
                'absent': 'Absent',
                'leave': 'Leave',
                'half-day': 'Half Day'
            };
            
            const mappedStatus = statusMap[data.status] || 'Present';
            
            // Use INSERT ... ON CONFLICT for PostgreSQL (replaces MySQL's ON DUPLICATE KEY UPDATE)
            const result = await db.query(
                `INSERT INTO attendance_leaves 
                 (tenant_id, employee_id, date, status, leave_type, reason)
                 VALUES ($1, $2, $3, $4, $5, $6)
                 ON CONFLICT (tenant_id, employee_id, date) 
                 DO UPDATE SET 
                    status = EXCLUDED.status,
                    leave_type = EXCLUDED.leave_type,
                    reason = EXCLUDED.reason,
                    updated_at = CURRENT_TIMESTAMP
                 RETURNING id`,
                [
                    tenantId,
                    data.employee_id, 
                    data.date, 
                    mappedStatus,
                    data.leave_type || null, 
                    data.reason || null
                ]
            );
            
            return { 
                id: result.rows[0].id,
                success: true
            };
        } catch (error) {
            throw error;
        }
    },

    // Get all active employees for a specific tenant - Promise style
    getAllEmployees: async (tenantId) => {
        try {
            const result = await db.query(
                `SELECT id, name, department FROM employees 
                 WHERE status = 'Active' AND tenant_id = $1
                 ORDER BY department, name
                 LIMIT 500`,  // Add limit for performance
                [tenantId]
            );
            return result.rows;
        } catch (error) {
            throw error;
        }
    }
};

module.exports = Attendance;
