const db = require("./mainModel");

// Total Revenue: Total money earned (sales only, as per schema)
async function getTotalRevenue(tenantId) {
    const result = await db.query(
        'SELECT COALESCE(SUM(grand_total), 0) AS total_revenue FROM bills WHERE tenant_id = $1',
        [tenantId]
    );
    return parseFloat(result.rows[0]?.total_revenue || 0);
}

// Total Expenses: Inventory purchases + salaries + other expenses
async function getTotalExpenses(tenantId) {
    // Inventory expenses: sum of (purchase_price * stock_qty) for all items
    const invResult = await db.query(
        'SELECT COALESCE(SUM(purchase_price * stock_qty), 0) AS inventory_expense FROM inventory_items WHERE tenant_id = $1',
        [tenantId]
    );
    const inventoryExpense = parseFloat(invResult.rows[0]?.inventory_expense || 0);

    // Salary expenses: sum of all final_salary from salary_details for the current month
    let salaryExpense = 0;
    try {
        const date = new Date();
        const currentMonthYear = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        
        const salResult = await db.query(
            'SELECT COALESCE(SUM(COALESCE(final_salary, 0)), 0) AS salary_expense FROM salary_details WHERE tenant_id = $1 AND month_year = $2', 
            [tenantId, currentMonthYear]
        );
        salaryExpense = parseFloat(salResult.rows[0]?.salary_expense || 0);
    } catch (e) {
        console.error('Error fetching salary expense data:', e);
    }

    // Add maintenance expenses if the table exists
    let maintenanceExpense = 0;
    try {
        const maintResult = await db.query(
            'SELECT COALESCE(SUM(amount), 0) AS maintenance_expense FROM maintenance_expenses WHERE tenant_id = $1',
            [tenantId]
        );
        maintenanceExpense = parseFloat(maintResult.rows[0]?.maintenance_expense || 0);
    } catch (e) {
        // If maintenance_expenses table does not exist, ignore
        console.error('Error fetching maintenance expense data:', e);
    }

    // Return the total of all expense types
    return inventoryExpense + salaryExpense + maintenanceExpense;
}

// Net Profit / Loss: Total profit from sales (selling price - purchase price)
async function getNetProfitOrLoss(tenantId) {
    const sql = `
        SELECT COALESCE(SUM((bi.item_price - ii.purchase_price) * bi.quantity), 0) AS total_profit
        FROM bill_items bi
        JOIN inventory_items ii ON bi.tenant_id = ii.tenant_id AND bi.item_code = ii.item_code
        WHERE bi.tenant_id = $1 
        AND bi.item_price IS NOT NULL 
        AND ii.purchase_price IS NOT NULL
    `;
    const result = await db.query(sql, [tenantId]);
    return parseFloat(result.rows[0]?.total_profit || 0);
}

// Get inventory cost (sum of inventory purchases)
async function getInventoryCost(tenantId) {
    const result = await db.query(
        'SELECT COALESCE(SUM(purchase_price * stock_qty), 0) AS inventory_cost FROM inventory_items WHERE tenant_id = $1',
        [tenantId]
    );
    return parseFloat(result.rows[0]?.inventory_cost || 0);
}

// Get total salaries for the current month
async function getTotalSalaries(tenantId) {
    try {
        // Get current month and year in 'YYYY-MM' format for filtering
        const date = new Date();
        const currentMonthYear = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        
        // Query to get sum of final_salary for the current month
        const result = await db.query(
            'SELECT COALESCE(SUM(COALESCE(final_salary, 0)), 0) AS total_salaries FROM salary_details WHERE tenant_id = $1 AND month_year = $2', 
            [tenantId, currentMonthYear]
        );
        return parseFloat(result.rows[0]?.total_salaries || 0);
    } catch (e) {
        console.error('Error fetching salary data:', e);
        return 0;
    }
}

// Get today's income
async function getTodayIncome(tenantId) {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    const result = await db.query(
        'SELECT COALESCE(SUM(grand_total), 0) AS today_income FROM bills WHERE tenant_id = $1 AND DATE(bill_date) = $2',
        [tenantId, today]
    );
    return parseFloat(result.rows[0]?.today_income || 0);
}

async function getTodayExpenses(tenantId) {
    try {
        const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
        const result = await db.query(
            'SELECT COALESCE(SUM(amount), 0) AS today_expenses FROM maintenance_expenses WHERE tenant_id = $1 AND DATE(entry_date) = $2', 
            [tenantId, today]
        );
        return parseFloat(result.rows[0]?.today_expenses || 0);
    } catch (e) {
        console.error('Error fetching today\'s expenses:', e);
        return 0;
    }
}

// Get total discount given
async function getTotalDiscount(tenantId) {
    const result = await db.query(
        'SELECT COALESCE(SUM(discount), 0) AS total_discount FROM bills WHERE tenant_id = $1',
        [tenantId]
    );
    return parseFloat(result.rows[0]?.total_discount || 0);
}

// Get total GST collected
async function getTotalGST(tenantId) {
    const result = await db.query(
        'SELECT COALESCE(SUM(gst), 0) AS total_gst FROM bills WHERE tenant_id = $1',
        [tenantId]
    );
    return parseFloat(result.rows[0]?.total_gst || 0);
}

// Get total customer khata pending (bills with payment_method = 'Credit')
async function getTotalCustomerKhataPending(tenantId) {
    const result = await db.query(
        "SELECT COALESCE(SUM(grand_total), 0) AS total_khata FROM bills WHERE tenant_id = $1 AND payment_method = 'Credit'",
        [tenantId]
    );
    return parseFloat(result.rows[0]?.total_khata || 0);
}

// Get salary details for a specific month with employee names
async function getSalaryDetailsByMonth(tenantId, monthYear) {
    try {
        const query = `
            SELECT 
                sd.id,
                e.name AS employee_name,
                COALESCE(sd.base_salary, 0) AS base_salary,
                COALESCE(sd.bonus, 0) AS bonus,
                COALESCE(sd.deductions, 0) AS deductions,
                COALESCE(sd.leave_deduction, 0) AS leave_deduction,
                COALESCE(sd.net_salary, 0) AS net_salary,
                COALESCE(sd.final_salary, 0) AS final_salary,
                sd.payment_date
            FROM 
                salary_details sd
            JOIN 
                employees e ON sd.employee_id = e.id AND sd.tenant_id = e.tenant_id
            WHERE 
                sd.tenant_id = $1 AND sd.month_year = $2
            ORDER BY 
                e.name ASC
        `;
        
        const result = await db.query(query, [tenantId, monthYear]);
        return result.rows;
    } catch (err) {
        console.error('Error fetching salary details by month:', err);
        throw err;
    }
}

// Add a new maintenance expense
async function addMaintenanceExpense(tenantId, expenseData) {
    try {
        const { entry_date, expense_type, brief, amount } = expenseData;
        
        const query = `
            INSERT INTO maintenance_expenses 
            (tenant_id, entry_date, expense_type, brief, amount) 
            VALUES ($1, $2, $3, $4, $5)
            RETURNING id
        `;
        
        const result = await db.query(query, [
            tenantId,
            entry_date, 
            expense_type, 
            brief, 
            amount
        ]);
        
        return result.rows[0].id;
    } catch (err) {
        console.error('Error adding maintenance expense:', err);
        throw err;
    }
}

// Get all maintenance expenses
async function getAllMaintenanceExpenses(tenantId) {
    try {
        const query = `
            SELECT 
                id,
                entry_date,
                expense_type,
                brief,
                amount,
                created_at
            FROM 
                maintenance_expenses
            WHERE tenant_id = $1
            ORDER BY 
                entry_date DESC
        `;
        
        const result = await db.query(query, [tenantId]);
        return result.rows;
    } catch (err) {
        console.error('Error fetching maintenance expenses:', err);
        throw err;
    }
}

// Get today's expense details
async function getTodayExpensesDetails(tenantId) {
    try {
        const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
        const query = `
            SELECT 
                id,
                entry_date,
                expense_type,
                brief,
                amount,
                created_at
            FROM 
                maintenance_expenses
            WHERE tenant_id = $1 AND DATE(entry_date) = $2
            ORDER BY 
                created_at DESC
        `;
        
        const result = await db.query(query, [tenantId, today]);
        return result.rows;
    } catch (err) {
        console.error('Error fetching today\'s expense details:', err);
        throw err;
    }
}

// Get total supplier khata amount
async function getTotalSupplierKhataPending(tenantId) {
    try {
        const result = await db.query(
            "SELECT COALESCE(SUM(amount), 0) AS total_pending FROM supplier_khata WHERE tenant_id = $1 AND payment_status = 'pending'",
            [tenantId]
        );
        return parseFloat(result.rows[0]?.total_pending || 0);
    } catch (err) {
        console.error('Error fetching total supplier khata pending:', err);
        return 0;
    }
}

// Add a new supplier khata entry
async function addSupplierKhata(tenantId, khataData) {
    try {
        const { entry_date, supplier_name, phone_number, amount, due_date, khata_cycle } = khataData;
        
        const query = `
            INSERT INTO supplier_khata 
            (tenant_id, entry_date, supplier_name, phone_number, amount, due_date, khata_cycle) 
            VALUES ($1, $2, $3, $4, $5, $6, $7)
            RETURNING id
        `;
        
        const result = await db.query(query, [
            tenantId,
            entry_date, 
            supplier_name, 
            phone_number, 
            amount, 
            due_date, 
            khata_cycle
        ]);
        
        return result.rows[0].id;
    } catch (err) {
        console.error('Error adding supplier khata:', err);
        throw err;
    }
}

// Get all supplier khata entries
async function getAllSupplierKhata(tenantId) {
    try {
        const query = `
            SELECT 
                id,
                entry_date,
                supplier_name,
                phone_number,
                amount,
                due_date,
                khata_cycle,
                payment_status,
                created_at
            FROM 
                supplier_khata
            WHERE tenant_id = $1
            ORDER BY 
                due_date ASC
        `;
        
        const result = await db.query(query, [tenantId]);
        return result.rows;
    } catch (err) {
        console.error('Error fetching supplier khata entries:', err);
        throw err;
    }
}

// Get upcoming due dates (for the next 3 days)
async function getUpcomingDueDates(tenantId) {
    try {
        const today = new Date().toISOString().split('T')[0];
        const threeDaysLater = new Date();
        threeDaysLater.setDate(threeDaysLater.getDate() + 3);
        const formattedThreeDaysLater = threeDaysLater.toISOString().split('T')[0];
        
        const query = `
            SELECT 
                id,
                supplier_name,
                amount,
                due_date
            FROM 
                supplier_khata
            WHERE 
                tenant_id = $1 
                AND payment_status = 'pending'
                AND due_date BETWEEN $2 AND $3
            ORDER BY 
                due_date ASC
        `;
        
        const result = await db.query(query, [tenantId, today, formattedThreeDaysLater]);
        return result.rows;
    } catch (err) {
        console.error('Error fetching upcoming due dates:', err);
        throw err;
    }
}

// Get customer khata details (customers with pending credit)
async function getCustomerKhataDetails(tenantId) {
    try {
        const query = `
            SELECT 
                bill_id,
                bill_date,
                customer_name,
                customer_phone,
                grand_total
            FROM 
                bills
            WHERE 
                tenant_id = $1 AND payment_method = 'Credit'
            ORDER BY 
                bill_date DESC
        `;
        
        const result = await db.query(query, [tenantId]);
        return result.rows;
    } catch (err) {
        console.error('Error fetching customer khata details:', err);
        throw err;
    }
}

// Update bill payment method (change from Credit to another payment method)
async function updateBillPaymentMethod(tenantId, billId, newPaymentMethod) {
    try {
        if (!['Cash', 'UPI', 'Debit', 'Card'].includes(newPaymentMethod)) {
            throw new Error('Invalid payment method. Must be Cash, UPI, Debit, or Card');
        }
        
        const query = `
            UPDATE bills
            SET payment_method = $1, updated_at = CURRENT_TIMESTAMP
            WHERE tenant_id = $2 AND bill_id = $3 AND payment_method = 'Credit'
        `;
        
        const result = await db.query(query, [newPaymentMethod, tenantId, billId]);
        
        return result.rowCount > 0;
    } catch (err) {
        console.error('Error updating bill payment method:', err);
        throw err;
    }
}

// Pay a specific supplier khata entry
async function paySupplierKhata(tenantId, khataId) {
    try {
        // Update the payment status to 'paid' instead of deleting
        const updateQuery = `
            UPDATE supplier_khata 
            SET payment_status = 'paid', 
                paid_amount = amount, 
                updated_at = CURRENT_TIMESTAMP
            WHERE tenant_id = $1 AND id = $2 AND payment_status = 'pending'
        `;
        
        const result = await db.query(updateQuery, [tenantId, khataId]);
        
        return result.rowCount;
    } catch (err) {
        console.error('Error paying supplier khata:', err);
        throw err;
    }
}

// Clear all supplier khata entries
async function clearAllSupplierKhata(tenantId) {
    try {
        // Mark all pending entries as paid instead of deleting
        const updateQuery = `
            UPDATE supplier_khata 
            SET payment_status = 'paid', 
                paid_amount = amount, 
                updated_at = CURRENT_TIMESTAMP,
                notes = CONCAT(COALESCE(notes, ''), ' [Bulk payment on ', CURRENT_TIMESTAMP, ']')
            WHERE tenant_id = $1 AND payment_status = 'pending'
        `;
        
        const result = await db.query(updateQuery, [tenantId]);
        
        return result.rowCount;
    } catch (err) {
        console.error('Error clearing supplier khata:', err);
        throw err;
    }
}

// Get all inventory items for expenses breakdown
async function getInventoryItems(tenantId) {
    try {
        const query = `
            SELECT item_code, item_name, category, purchase_price, stock_qty
            FROM inventory_items
            WHERE tenant_id = $1
            ORDER BY item_name
        `;
        const result = await db.query(query, [tenantId]);
        return result.rows;
    } catch (err) {
        console.error('Error fetching inventory items:', err);
        throw err;
    }
}

// Get total maintenance expenses
async function getMaintenanceExpensesTotal(tenantId) {
    try {
        const query = `
            SELECT COALESCE(SUM(amount), 0) AS total
            FROM maintenance_expenses
            WHERE tenant_id = $1
        `;
        const result = await db.query(query, [tenantId]);
        return parseFloat(result.rows[0]?.total || 0);
    } catch (err) {
        console.error('Error fetching maintenance expenses total:', err);
        return 0;
    }
}

module.exports = {
    getTotalRevenue,
    getTotalExpenses,
    getNetProfitOrLoss,
    getInventoryCost,
    getTotalSalaries,
    getTodayIncome,
    getTodayExpenses,
    getTodayExpensesDetails,
    getTotalDiscount,
    getTotalGST,
    getTotalCustomerKhataPending,
    getSalaryDetailsByMonth,
    addMaintenanceExpense,
    getAllMaintenanceExpenses,
    getTotalSupplierKhataPending,
    addSupplierKhata,
    getAllSupplierKhata,
    getUpcomingDueDates,
    getCustomerKhataDetails,
    updateBillPaymentMethod,
    clearAllSupplierKhata,
    paySupplierKhata,
    getInventoryItems,
    getMaintenanceExpensesTotal
};