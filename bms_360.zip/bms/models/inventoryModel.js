const db = require("./mainModel");

/**
 * Inventory Model - PostgreSQL Multi-Tenant Support
 * Supports any business type through flexible categorization and customizable fields
 */

// Function to Fetch inventory items for a specific tenant
const getinvmodel = async (tenantId) => {
    const sql = `
        SELECT id, item_name, item_code, category, stock_qty, purchase_price, 
               selling_price, created_at, updated_at, tenant_id 
        FROM inventory_items 
        WHERE tenant_id = $1
        ORDER BY created_at DESC
    `;
    const result = await db.query(sql, [tenantId]);
    return result.rows;
};

// Function to Search inventory items for a specific tenant
const searchInvModel = async (tenantId, search, category) => {
    let sql = `
        SELECT * FROM inventory_items 
        WHERE tenant_id = $1
    `;
    let params = [tenantId];
    let paramCount = 1;

    if (search) {
        paramCount++;
        sql += ` AND (item_name ILIKE $${paramCount} OR item_code ILIKE $${paramCount})`;
        params.push(`%${search}%`);
    }
    
    if (category) {
        paramCount++;
        sql += ` AND category = $${paramCount}`;
        params.push(category);
    }

    sql += ` ORDER BY created_at DESC`;
    
    const result = await db.query(sql, params);
    return result.rows;
};

// Check stock for a given item code within a tenant
const checkStock = async (tenantId, item_code) => {
    const sql = `
        SELECT stock_qty FROM inventory_items 
        WHERE tenant_id = $1 AND item_code = $2
    `;
    const result = await db.query(sql, [tenantId, item_code]);
    if (result.rows.length === 0) return 0;
    return result.rows[0].stock_qty;
};

// Update stock for a given item code (decrement by qty) within a tenant
const updateStock = async (tenantId, item_code, qty) => {
    const sql = `
        UPDATE inventory_items 
        SET stock_qty = stock_qty - $1, updated_at = CURRENT_TIMESTAMP 
        WHERE tenant_id = $2 AND item_code = $3 AND stock_qty >= $1
    `;
    const result = await db.query(sql, [qty, tenantId, item_code]);
    if (result.rowCount === 0) {
        throw new Error('Not enough stock or item not found');
    }
    return result.rowCount;
};

// Increment stock for a given item code within a tenant
const incrementStock = async (tenantId, item_code, qty) => {
    const sql = `
        UPDATE inventory_items 
        SET stock_qty = stock_qty + $1, updated_at = CURRENT_TIMESTAMP 
        WHERE tenant_id = $2 AND item_code = $3
    `;
    const result = await db.query(sql, [qty, tenantId, item_code]);
    if (result.rowCount === 0) {
        throw new Error('Item not found');
    }
    return result.rowCount;
};

// Add a new product to inventory for a specific tenant
const addProduct = async (tenantId, product) => {
    const { item_name, item_code, category, stock_qty, purchase_price, selling_price } = product;
    
    // Check if product with same code already exists for this tenant
    const existingCheck = await db.query(
        "SELECT item_code FROM inventory_items WHERE tenant_id = $1 AND item_code = $2",
        [tenantId, item_code]
    );
    
    if (existingCheck.rows.length > 0) {
        throw new Error('Product with this code already exists');
    }
    
    const sql = `
        INSERT INTO inventory_items 
        (tenant_id, item_name, item_code, category, stock_qty, purchase_price, 
         selling_price, created_at, updated_at) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        RETURNING id
    `;
    
    const result = await db.query(sql, [
        tenantId,
        item_name, 
        item_code, 
        category, 
        stock_qty, 
        purchase_price, 
        selling_price
    ]);
    
    return result.rows[0].id;
};

// Delete a product from inventory for a specific tenant
const deleteProduct = async (tenantId, item_code) => {
    const sql = "DELETE FROM inventory_items WHERE tenant_id = $1 AND item_code = $2";
    const result = await db.query(sql, [tenantId, item_code]);
    if (result.rowCount === 0) {
        throw new Error('Product not found');
    }
    return result.rowCount;
};

// Get all unique categories from the inventory for a specific tenant
const getAllCategories = async (tenantId) => {
    const sql = `
        SELECT DISTINCT category FROM inventory_items 
        WHERE tenant_id = $1 
        ORDER BY category
    `;
    const result = await db.query(sql, [tenantId]);
    return result.rows.map(row => row.category);
};

// Get product details by item code for a specific tenant
const getProductByCode = async (tenantId, item_code) => {
    const sql = "SELECT * FROM inventory_items WHERE tenant_id = $1 AND item_code = $2";
    const result = await db.query(sql, [tenantId, item_code]);
    if (result.rows.length === 0) {
        throw new Error('Product not found');
    }
    return result.rows[0];
};

// Update product details for a specific tenant
const updateProduct = async (tenantId, item_code, updates) => {
    const { item_name, category, purchase_price, selling_price } = updates;
    const sql = `
        UPDATE inventory_items 
        SET item_name = $1, category = $2, purchase_price = $3, 
            selling_price = $4, updated_at = CURRENT_TIMESTAMP
        WHERE tenant_id = $5 AND item_code = $6
    `;
    const result = await db.query(sql, [
        item_name, 
        category, 
        purchase_price, 
        selling_price,
        tenantId,
        item_code
    ]);
    if (result.rowCount === 0) {
        throw new Error('Product not found');
    }
    return result.rowCount;
};

// Get low stock items for a specific tenant (customizable threshold)
const getLowStockItems = async (tenantId, threshold = 10) => {
    const sql = `
        SELECT * FROM inventory_items 
        WHERE tenant_id = $1 AND stock_qty <= $2
        ORDER BY stock_qty ASC
    `;
    const result = await db.query(sql, [tenantId, threshold]);
    return result.rows;
};

// Get inventory statistics for a specific tenant
const getInventoryStats = async (tenantId) => {
    const sql = `
        SELECT 
            COUNT(*) as total_items,
            SUM(stock_qty) as total_stock,
            SUM(stock_qty * purchase_price) as total_purchase_value,
            SUM(stock_qty * selling_price) as total_selling_value,
            COUNT(DISTINCT category) as total_categories
        FROM inventory_items 
        WHERE tenant_id = $1
    `;
    const result = await db.query(sql, [tenantId]);
    return result.rows[0];
};

// Bulk update stock (for batch operations)
const bulkUpdateStock = async (tenantId, updates) => {
    const client = await db.connect();
    try {
        await client.query('BEGIN');
        
        const results = [];
        for (const update of updates) {
            const { item_code, qty, operation } = update;
            const sql = operation === 'increment' 
                ? `UPDATE inventory_items SET stock_qty = stock_qty + $1, updated_at = CURRENT_TIMESTAMP WHERE tenant_id = $2 AND item_code = $3`
                : `UPDATE inventory_items SET stock_qty = stock_qty - $1, updated_at = CURRENT_TIMESTAMP WHERE tenant_id = $2 AND item_code = $3 AND stock_qty >= $1`;
            
            const result = await client.query(sql, [qty, tenantId, item_code]);
            results.push({ item_code, success: result.rowCount > 0 });
        }
        
        await client.query('COMMIT');
        return results;
    } catch (error) {
        await client.query('ROLLBACK');
        throw error;
    } finally {
        client.release();
    }
};

module.exports = { 
    getinvmodel, 
    searchInvModel, 
    checkStock, 
    updateStock, 
    incrementStock, 
    addProduct, 
    deleteProduct, 
    getAllCategories, 
    getProductByCode, 
    updateProduct,
    getLowStockItems,
    getInventoryStats,
    bulkUpdateStock
};