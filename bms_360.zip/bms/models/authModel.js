const db = require('./mainModel');
const { logger } = require('../utils/logger');

/**
 * Authentication Model
 * Database operations for multi-tenant authentication
 */

/**
 * Find tenant by email
 */
const findTenantByEmail = async (email) => {
    try {
        const sql = 'SELECT * FROM tenants WHERE owner_email = $1';
        const result = await db.query(sql, [email]);
        return result.rows[0] || null;
    } catch (error) {
        logger.error('Error finding tenant by email:', error);
        throw error;
    }
};

/**
 * Find tenant by ID
 */
const findTenantById = async (tenantId) => {
    try {
        const sql = 'SELECT * FROM tenants WHERE tenant_id = $1';
        const result = await db.query(sql, [tenantId]);
        return result.rows[0] || null;
    } catch (error) {
        logger.error('Error finding tenant by ID:', error);
        throw error;
    }
};

/**
 * Create new tenant
 */
const createTenant = async (tenantData) => {
    try {
        const {
            business_name,
            owner_first_name,
            owner_last_name,
            owner_email,
            owner_password,
            tagline,
            contact_address,
            phone,
            subscription_plan,
            subscription_status,
            trial_ends_at
        } = tenantData;

        const sql = `
            INSERT INTO tenants (
                business_name,
                owner_first_name,
                owner_last_name,
                owner_email,
                owner_password,
                tagline,
                contact_address,
                phone,
                subscription_plan,
                subscription_status,
                trial_ends_at,
                is_active
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, TRUE)
            RETURNING tenant_id, business_name, owner_email, subscription_plan
        `;

        const values = [
            business_name,
            owner_first_name,
            owner_last_name,
            owner_email,
            owner_password,
            tagline,
            contact_address,
            phone,
            subscription_plan,
            subscription_status,
            trial_ends_at
        ];

        const result = await db.query(sql, values);
        return result.rows[0];
    } catch (error) {
        logger.error('Error creating tenant:', error);
        throw error;
    }
};

/**
 * Find employee by email
 */
const findEmployeeByEmail = async (email) => {
    try {
        const sql = 'SELECT * FROM employees WHERE email = $1';
        const result = await db.query(sql, [email]);
        return result.rows[0] || null;
    } catch (error) {
        logger.error('Error finding employee by email:', error);
        throw error;
    }
};

/**
 * Find employee by ID
 */
const findEmployeeById = async (employeeId) => {
    try {
        const sql = 'SELECT * FROM employees WHERE id = $1';
        const result = await db.query(sql, [employeeId]);
        return result.rows[0] || null;
    } catch (error) {
        logger.error('Error finding employee by ID:', error);
        throw error;
    }
};

/**
 * Increment login attempts
 * @param {number} id - User ID (tenant_id or employee id)
 * @param {string} userType - 'tenant' or 'employee'
 */
const incrementLoginAttempts = async (id, userType) => {
    try {
        const table = userType === 'tenant' ? 'tenants' : 'employees';
        const idField = userType === 'tenant' ? 'tenant_id' : 'id';
        
        const sql = `
            UPDATE ${table}
            SET login_attempts = login_attempts + 1,
                updated_at = CURRENT_TIMESTAMP
            WHERE ${idField} = $1
        `;
        
        await db.query(sql, [id]);
    } catch (error) {
        logger.error('Error incrementing login attempts:', error);
        throw error;
    }
};

/**
 * Reset login attempts
 * @param {number} id - User ID (tenant_id or employee id)
 * @param {string} userType - 'tenant' or 'employee'
 */
const resetLoginAttempts = async (id, userType) => {
    try {
        const table = userType === 'tenant' ? 'tenants' : 'employees';
        const idField = userType === 'tenant' ? 'tenant_id' : 'id';
        
        const sql = `
            UPDATE ${table}
            SET login_attempts = 0,
                locked_until = NULL,
                updated_at = CURRENT_TIMESTAMP
            WHERE ${idField} = $1
        `;
        
        await db.query(sql, [id]);
    } catch (error) {
        logger.error('Error resetting login attempts:', error);
        throw error;
    }
};

/**
 * Lock account
 * @param {number} id - User ID (tenant_id or employee id)
 * @param {number} minutes - Lock duration in minutes
 * @param {string} userType - 'tenant' or 'employee'
 */
const lockAccount = async (id, minutes, userType) => {
    try {
        const table = userType === 'tenant' ? 'tenants' : 'employees';
        const idField = userType === 'tenant' ? 'tenant_id' : 'id';
        
        const lockUntil = new Date(Date.now() + minutes * 60000);
        
        const sql = `
            UPDATE ${table}
            SET locked_until = $1,
                updated_at = CURRENT_TIMESTAMP
            WHERE ${idField} = $2
        `;
        
        await db.query(sql, [lockUntil, id]);
    } catch (error) {
        logger.error('Error locking account:', error);
        throw error;
    }
};

/**
 * Update last login information
 * @param {number} id - User ID (tenant_id or employee id)
 * @param {string} ipAddress - Client IP address
 * @param {string} userType - 'tenant' or 'employee'
 */
const updateLastLogin = async (id, ipAddress, userType) => {
    try {
        const table = userType === 'tenant' ? 'tenants' : 'employees';
        const idField = userType === 'tenant' ? 'tenant_id' : 'id';
        
        const sql = `
            UPDATE ${table}
            SET last_login_at = CURRENT_TIMESTAMP,
                last_login_ip = $1,
                updated_at = CURRENT_TIMESTAMP
            WHERE ${idField} = $2
        `;
        
        await db.query(sql, [ipAddress, id]);
    } catch (error) {
        logger.error('Error updating last login:', error);
        throw error;
    }
};

/**
 * Update tenant password
 */
const updateTenantPassword = async (tenantId, hashedPassword) => {
    try {
        const sql = `
            UPDATE tenants
            SET owner_password = $1,
                updated_at = CURRENT_TIMESTAMP
            WHERE tenant_id = $2
        `;
        
        await db.query(sql, [hashedPassword, tenantId]);
    } catch (error) {
        logger.error('Error updating tenant password:', error);
        throw error;
    }
};

/**
 * Update employee password
 */
const updateEmployeePassword = async (employeeId, hashedPassword) => {
    try {
        const sql = `
            UPDATE employees
            SET password = $1,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = $2
        `;
        
        await db.query(sql, [hashedPassword, employeeId]);
    } catch (error) {
        logger.error('Error updating employee password:', error);
        throw error;
    }
};

/**
 * Get all employees for a tenant
 */
const getEmployeesByTenant = async (tenantId) => {
    try {
        const sql = `
            SELECT id, name, email, phone, department, role, status, date_of_joining, created_at
            FROM employees
            WHERE tenant_id = $1
            ORDER BY created_at DESC
        `;
        
        const result = await db.query(sql, [tenantId]);
        return result.rows;
    } catch (error) {
        logger.error('Error getting employees by tenant:', error);
        throw error;
    }
};

module.exports = {
    findTenantByEmail,
    findTenantById,
    createTenant,
    findEmployeeByEmail,
    findEmployeeById,
    incrementLoginAttempts,
    resetLoginAttempts,
    lockAccount,
    updateLastLogin,
    updateTenantPassword,
    updateEmployeePassword,
    getEmployeesByTenant
};
