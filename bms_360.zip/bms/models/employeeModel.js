const db = require("./mainModel");

// Function to fetch all employees for a specific tenant
const getAllEmployees = async (tenantId) => {
    try {
        const result = await db.query(`
            SELECT 
                id, 
                name, 
                email, 
                phone, 
                department, 
                role,
                salary, 
                date_of_joining, 
                status,
                created_at
            FROM employees
            WHERE tenant_id = $1
            ORDER BY created_at DESC
        `, [tenantId]);
        return { success: true, data: result.rows };
    } catch (error) {
        console.error("Error fetching employees:", error);
        return { success: false, error: error.message };
    }
};

// Function to fetch employee by ID for a specific tenant
const getEmployeeById = async (employeeId, tenantId) => {
    try {
        const result = await db.query(`
            SELECT 
                id, 
                name, 
                email, 
                phone, 
                department,
                role, 
                salary, 
                date_of_joining, 
                status,
                tenant_id
            FROM employees 
            WHERE id = $1 AND tenant_id = $2
        `, [employeeId, tenantId]);
        
        if (result.rows.length === 0) {
            return { success: false, error: "Employee not found" };
        }
        
        return { success: true, data: result.rows[0] };
    } catch (error) {
        console.error("Error fetching employee by ID:", error);
        return { success: false, error: error.message };
    }
};

// Legacy function - keeping for backward compatibility
const getempmodel = (callback) => {
    const sql = "SELECT id, name, age, position, salary, email, created_at FROM employee";
    db.query(sql, (err, results) => {
        if (err) return callback(err, null);
        callback(null, results);
    });
};

// Function to create initial salary entry for a new employee
const createInitialSalaryEntry = async (employeeId, baseSalary, tenantId) => {
    try {
        // Get current date in YYYY-MM format
        const today = new Date();
        const monthYear = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
        
        // Calculate default values
        const bonus = 0.00;
        const deductions = 0.00;
        const leaveDeduction = 0.00;
        const netSalary = parseFloat(baseSalary) - deductions - leaveDeduction;
        const finalSalary = netSalary + parseFloat(bonus);
        
        // Insert initial salary entry
        await db.query(`
            INSERT INTO salary_details (
                tenant_id,
                employee_id, 
                month_year, 
                base_salary, 
                bonus, 
                deductions, 
                leave_deduction, 
                net_salary, 
                final_salary, 
                payment_date
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NULL)
        `, [
            tenantId,
            employeeId,
            monthYear,
            baseSalary,
            bonus,
            deductions,
            leaveDeduction,
            netSalary,
            finalSalary
        ]);
        
        return { success: true, message: "Initial salary entry created successfully" };
    } catch (error) {
        console.error("Error creating initial salary entry:", error);
        return { success: false, error: error.message };
    }
};

// Function to update salary details for an employee
const updateSalaryDetails = async (employeeId, salaryData, tenantId) => {
    try {
        const { 
            month_year, 
            base_salary, 
            bonus = 0, 
            deductions = 0, 
            leave_deduction = 0, 
            payment_date = null 
        } = salaryData;
        
        // Calculate net and final salary
        const netSalary = parseFloat(base_salary) - parseFloat(deductions) - parseFloat(leave_deduction);
        const finalSalary = netSalary + parseFloat(bonus);
        
        // Check if an entry already exists for this employee and month
        const existingEntries = await db.query(
            'SELECT id FROM salary_details WHERE employee_id = $1 AND month_year = $2 AND tenant_id = $3',
            [employeeId, month_year, tenantId]
        );
        
        if (existingEntries.rows.length > 0) {
            // Update existing entry
            await db.query(`
                UPDATE salary_details 
                SET 
                    base_salary = $1,
                    bonus = $2,
                    deductions = $3,
                    leave_deduction = $4,
                    net_salary = $5,
                    final_salary = $6,
                    payment_date = $7,
                    updated_at = CURRENT_TIMESTAMP
                WHERE employee_id = $8 AND month_year = $9 AND tenant_id = $10
            `, [
                base_salary,
                bonus,
                deductions,
                leave_deduction,
                netSalary,
                finalSalary,
                payment_date,
                employeeId,
                month_year,
                tenantId
            ]);
            
            return { success: true, message: "Salary details updated successfully" };
        } else {
            // Create new entry
            await db.query(`
                INSERT INTO salary_details (
                    tenant_id,
                    employee_id, 
                    month_year, 
                    base_salary, 
                    bonus, 
                    deductions, 
                    leave_deduction, 
                    net_salary, 
                    final_salary, 
                    payment_date
                ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
            `, [
                tenantId,
                employeeId,
                month_year,
                base_salary,
                bonus,
                deductions,
                leave_deduction,
                netSalary,
                finalSalary,
                payment_date
            ]);
            
            return { success: true, message: "Salary details created successfully" };
        }
    } catch (error) {
        console.error("Error updating salary details:", error);
        return { success: false, error: error.message };
    }
};

// Function to get salary details for an employee
const getSalaryDetailsByEmployeeId = async (employeeId, tenantId) => {
    try {
        const result = await db.query(`
            SELECT 
                id,
                employee_id,
                month_year,
                base_salary,
                bonus,
                deductions,
                leave_deduction,
                net_salary,
                final_salary,
                payment_date,
                payment_status
            FROM salary_details 
            WHERE employee_id = $1 AND tenant_id = $2
            ORDER BY month_year DESC
        `, [employeeId, tenantId]);
        
        return { success: true, data: result.rows };
    } catch (error) {
        console.error("Error fetching salary details:", error);
        return { success: false, error: error.message };
    }
};

// Function to delete an employee by ID
const deleteEmployeeById = async (employeeId, tenantId) => {
    try {
        // Check if employee exists first
        const employee = await getEmployeeById(employeeId, tenantId);
        if (!employee.success) {
            return { success: false, error: "Employee not found" };
        }
        
        // Delete the employee (CASCADE will handle salary_details, attendance, etc.)
        const result = await db.query('DELETE FROM employees WHERE id = $1 AND tenant_id = $2', [employeeId, tenantId]);
        
        if (result.rowCount === 0) {
            return { success: false, error: "Employee not found or already deleted" };
        }
        
        return { success: true, message: "Employee deleted successfully" };
    } catch (error) {
        console.error("Error deleting employee:", error);
        return { success: false, error: error.message };
    }
};

// Function to update an employee by ID
const updateEmployeeById = async (employeeId, employeeData, tenantId) => {
    try {
        // Check if employee exists first
        const employee = await getEmployeeById(employeeId, tenantId);
        if (!employee.success) {
            return { success: false, error: "Employee not found" };
        }
        
        // Build update query parts
        const updateFields = [];
        const values = [];
        let paramIndex = 1;
        
        if (employeeData.name !== undefined) {
            updateFields.push(`name = $${paramIndex++}`);
            values.push(employeeData.name);
        }
        if (employeeData.email !== undefined) {
            updateFields.push(`email = $${paramIndex++}`);
            values.push(employeeData.email);
        }
        if (employeeData.phone !== undefined) {
            updateFields.push(`phone = $${paramIndex++}`);
            values.push(employeeData.phone || null);
        }
        if (employeeData.department !== undefined) {
            updateFields.push(`department = $${paramIndex++}`);
            values.push(employeeData.department || null);
        }
        if (employeeData.role !== undefined) {
            updateFields.push(`role = $${paramIndex++}`);
            values.push(employeeData.role || 'employee');
        }
        if (employeeData.salary !== undefined) {
            updateFields.push(`salary = $${paramIndex++}`);
            values.push(employeeData.salary || null);
        }
        if (employeeData.date_of_joining !== undefined) {
            updateFields.push(`date_of_joining = $${paramIndex++}`);
            values.push(employeeData.date_of_joining || null);
        }
        if (employeeData.status !== undefined) {
            updateFields.push(`status = $${paramIndex++}`);
            values.push(employeeData.status);
        }
        if (employeeData.password) {
            updateFields.push(`password = $${paramIndex++}`);
            values.push(employeeData.password);
        }
        
        updateFields.push(`updated_at = CURRENT_TIMESTAMP`);
        
        // Add WHERE clause parameters
        values.push(employeeId);
        values.push(tenantId);
        
        // Update employee data
        const result = await db.query(`
            UPDATE employees
            SET ${updateFields.join(', ')}
            WHERE id = $${paramIndex++} AND tenant_id = $${paramIndex++}
        `, values);
        
        if (result.rowCount === 0) {
            return { success: false, error: "Employee not found or no changes made" };
        }
        
        // If salary is updated, also update the current month's salary entry
        if (employeeData.salary !== undefined && employeeData.salary !== null) {
            // Get current month-year
            const today = new Date();
            const monthYear = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}`;
            
            // Check if a salary entry exists for the current month
            const salaryEntries = await db.query(
                'SELECT id, base_salary FROM salary_details WHERE employee_id = $1 AND month_year = $2 AND tenant_id = $3',
                [employeeId, monthYear, tenantId]
            );
            
            if (salaryEntries.rows.length > 0) {
                // Update existing entry if the base salary has changed
                if (parseFloat(salaryEntries.rows[0].base_salary) !== parseFloat(employeeData.salary)) {
                    await updateSalaryDetails(employeeId, {
                        month_year: monthYear,
                        base_salary: employeeData.salary
                    }, tenantId);
                }
            } else {
                // Create new salary entry for the current month
                await createInitialSalaryEntry(employeeId, employeeData.salary, tenantId);
            }
        }
        
        return { success: true, message: "Employee updated successfully" };
    } catch (error) {
        console.error("Error updating employee:", error);
        
        // Handle unique email constraint violation for PostgreSQL
        if (error.code === '23505' && error.constraint && error.constraint.includes('email')) {
            return {
                success: false,
                error: "An employee with this email already exists"
            };
        }
        
        return { success: false, error: error.message };
    }
};

// Function to get all salary records with employee names for a tenant
const getAllSalaryRecords = async (tenantId) => {
    try {
        const result = await db.query(`
            SELECT 
                sd.id, 
                sd.employee_id, 
                e.name as employee_name,
                sd.month_year, 
                sd.base_salary, 
                sd.bonus, 
                sd.deductions, 
                sd.leave_deduction, 
                sd.net_salary, 
                sd.final_salary, 
                sd.payment_date,
                sd.payment_status
            FROM salary_details sd
            JOIN employees e ON sd.employee_id = e.id
            WHERE sd.tenant_id = $1
            ORDER BY sd.month_year DESC, e.name ASC
        `, [tenantId]);
        return { success: true, data: result.rows };
    } catch (error) {
        console.error("Error fetching salary records:", error);
        return { success: false, error: error.message };
    }
};

// Function to get salary record by ID for a tenant
const getSalaryById = async (salaryId, tenantId) => {
    try {
        const result = await db.query(`
            SELECT 
                id, 
                employee_id, 
                month_year, 
                base_salary, 
                bonus, 
                deductions, 
                leave_deduction, 
                net_salary, 
                final_salary, 
                payment_date,
                payment_status
            FROM salary_details 
            WHERE id = $1 AND tenant_id = $2
        `, [salaryId, tenantId]);
        
        if (result.rows.length === 0) {
            return { success: false, error: "Salary record not found" };
        }
        
        return { success: true, data: result.rows[0] };
    } catch (error) {
        console.error("Error fetching salary by ID:", error);
        return { success: false, error: error.message };
    }
};

// Function to create a new salary record
const createSalaryRecord = async (salaryData, tenantId) => {
    try {
        // Check if a record already exists for this employee and month/year
        const existingRecords = await db.query(`
            SELECT id FROM salary_details 
            WHERE employee_id = $1 AND month_year = $2 AND tenant_id = $3
        `, [salaryData.employee_id, salaryData.month_year, tenantId]);
        
        if (existingRecords.rows.length > 0) {
            return { 
                success: false, 
                error: "A salary record already exists for this employee and month/year" 
            };
        }
        
        // Calculate net and final salary
        const baseSalary = parseFloat(salaryData.base_salary);
        const bonus = parseFloat(salaryData.bonus || 0);
        const deductions = parseFloat(salaryData.deductions || 0);
        const leaveDeduction = parseFloat(salaryData.leave_deduction || 0);
        const netSalary = baseSalary - deductions - leaveDeduction;
        const finalSalary = netSalary + bonus;
        
        // Set payment date and status based on input
        const paymentDate = salaryData.payment_status === 'paid' ? salaryData.payment_date : null;
        const paymentStatus = salaryData.payment_status || 'pending';
        
        // Insert salary record
        const result = await db.query(`
            INSERT INTO salary_details (
                tenant_id,
                employee_id, 
                month_year, 
                base_salary, 
                bonus, 
                deductions, 
                leave_deduction, 
                net_salary, 
                final_salary, 
                payment_date,
                payment_status
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11)
            RETURNING id
        `, [
            tenantId,
            salaryData.employee_id,
            salaryData.month_year,
            baseSalary,
            bonus,
            deductions,
            leaveDeduction,
            netSalary,
            finalSalary,
            paymentDate,
            paymentStatus
        ]);
        
        return { 
            success: true, 
            message: "Salary record created successfully", 
            id: result.rows[0].id 
        };
    } catch (error) {
        console.error("Error creating salary record:", error);
        return { success: false, error: error.message };
    }
};

// Function to update a salary record
const updateSalaryRecord = async (salaryId, salaryData, tenantId) => {
    try {
        // Check if the record exists
        const existingRecords = await db.query(`
            SELECT id FROM salary_details WHERE id = $1 AND tenant_id = $2
        `, [salaryId, tenantId]);
        
        if (existingRecords.rows.length === 0) {
            return { success: false, error: "Salary record not found" };
        }
        
        // Calculate net and final salary
        const baseSalary = parseFloat(salaryData.base_salary);
        const bonus = parseFloat(salaryData.bonus || 0);
        const deductions = parseFloat(salaryData.deductions || 0);
        const leaveDeduction = parseFloat(salaryData.leave_deduction || 0);
        const netSalary = baseSalary - deductions - leaveDeduction;
        const finalSalary = netSalary + bonus;
        
        // Set payment date and status based on input
        const paymentDate = salaryData.payment_status === 'paid' ? salaryData.payment_date : null;
        const paymentStatus = salaryData.payment_status || 'pending';
        
        // Update salary record
        await db.query(`
            UPDATE salary_details SET
                employee_id = $1,
                month_year = $2,
                base_salary = $3,
                bonus = $4,
                deductions = $5,
                leave_deduction = $6,
                net_salary = $7,
                final_salary = $8,
                payment_date = $9,
                payment_status = $10,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = $11 AND tenant_id = $12
        `, [
            salaryData.employee_id,
            salaryData.month_year,
            baseSalary,
            bonus,
            deductions,
            leaveDeduction,
            netSalary,
            finalSalary,
            paymentDate,
            paymentStatus,
            salaryId,
            tenantId
        ]);
        
        return { success: true, message: "Salary record updated successfully" };
    } catch (error) {
        console.error("Error updating salary record:", error);
        return { success: false, error: error.message };
    }
};

// Function to mark a salary as paid
const markSalaryAsPaid = async (salaryId, paymentDate, tenantId) => {
    try {
        // Check if the record exists
        const existingRecords = await db.query(`
            SELECT id FROM salary_details WHERE id = $1 AND tenant_id = $2
        `, [salaryId, tenantId]);
        
        if (existingRecords.rows.length === 0) {
            return { success: false, error: "Salary record not found" };
        }
        
        // Update payment date and status
        await db.query(`
            UPDATE salary_details SET
                payment_date = $1,
                payment_status = 'paid',
                updated_at = CURRENT_TIMESTAMP
            WHERE id = $2 AND tenant_id = $3
        `, [paymentDate, salaryId, tenantId]);
        
        return { success: true, message: "Salary marked as paid successfully" };
    } catch (error) {
        console.error("Error marking salary as paid:", error);
        return { success: false, error: error.message };
    }
};

// Function to get all employees for dropdowns (basic info only)
const getAllEmployeesBasic = async (tenantId) => {
    try {
        const result = await db.query(`
            SELECT 
                id, 
                name, 
                salary,
                department,
                role
            FROM employees
            WHERE tenant_id = $1
            ORDER BY name ASC
        `, [tenantId]);
        return { success: true, data: result.rows };
    } catch (error) {
        console.error("Error fetching employees:", error);
        return { success: false, error: error.message };
    }
};

module.exports = { 
    getempmodel,
    getAllEmployees,
    getEmployeeById,
    createInitialSalaryEntry,
    updateSalaryDetails,
    getSalaryDetailsByEmployeeId,
    deleteEmployeeById,
    updateEmployeeById,
    getAllSalaryRecords,
    getSalaryById,
    createSalaryRecord,
    updateSalaryRecord,
    markSalaryAsPaid,
    getAllEmployeesBasic
};
