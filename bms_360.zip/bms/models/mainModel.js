const { Pool } = require("pg");
require('dotenv').config();

// Validate required environment variables
const requiredEnvVars = ['DB_HOST', 'DB_USER', 'DB_PASSWORD', 'DB_NAME'];
for (const envVar of requiredEnvVars) {
    if (!process.env[envVar]) {
        throw new Error(`Required environment variable ${envVar} is not set`);
    }
}

// Create PostgreSQL Connection Pool with environment variables
const pool = new Pool({
    host: process.env.DB_HOST || "localhost",
    user: process.env.DB_USER || "postgres",
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME || "bms",
    port: process.env.DB_PORT || 5432,
    // Connection pool configurations
    max: 20, // Maximum number of clients in the pool
    idleTimeoutMillis: 30000, // Close idle clients after 30 seconds
    connectionTimeoutMillis: 60000, // Return an error if connection takes longer than 60 seconds
    // Security configurations
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false,
});

// Test the database connection
pool.query('SELECT 1')
    .then(() => {
        console.log('✅ PostgreSQL database connection established successfully');
        console.log(`📊 Connected to database: ${process.env.DB_NAME || "bms"}`);
    })
    .catch((error) => {
        console.error('❌ PostgreSQL database connection failed:', error.message);
        process.exit(1);
    });

// Handle pool errors
pool.on('error', (err, client) => {
    console.error('Unexpected error on idle PostgreSQL client', err);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    pool.end(() => {
        console.log('PostgreSQL pool has ended');
    });
});

process.on('SIGINT', () => {
    pool.end(() => {
        console.log('PostgreSQL pool has ended');
    });
});

// Export the pool
module.exports = pool;
