const db = require('./mainModel');
const employeeModel = require('./employeeModel');

/**
 * Add a new employee to the database with tenant isolation
 * @param {Object} employeeData - Employee data from the form
 * @param {number} employeeData.tenant_id - Tenant ID for multi-tenant isolation
 * @param {string} employeeData.name - Full name of the employee
 * @param {string} employeeData.email - Email address of the employee
 * @param {string} employeeData.phone - Phone number of the employee
 * @param {string} employeeData.department - Department of the employee
 * @param {number} employeeData.salary - Salary of the employee
 * @param {string} employeeData.date_of_joining - Date of joining (YYYY-MM-DD)
 * @param {string} employeeData.status - Status of employee (Active, On Leave, Resigned)
 * @returns {Promise<Object>} Result of the operation
 */
const addEmployee = async (employeeData) => {
    try {
        // Validate required fields
        if (!employeeData.name || !employeeData.email || !employeeData.tenant_id) {
            return {
                success: false,
                error: "Name, email, and tenant_id are required fields"
            };
        }

        // Set default status if not provided
        if (!employeeData.status) {
            employeeData.status = 'Active';
        }

        // SQL query to insert employee data with tenant_id
        const query = `
            INSERT INTO employees (
                tenant_id,
                name, 
                email, 
                phone, 
                department, 
                salary, 
                date_of_joining, 
                status,
                password
            ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
            RETURNING id
        `;

        // Execute the query with the provided data
        const result = await db.query(query, [
            employeeData.tenant_id,
            employeeData.name,
            employeeData.email,
            employeeData.phone || null,
            employeeData.department || null,
            employeeData.salary || null,
            employeeData.date_of_joining || null,
            employeeData.status,
            employeeData.password
        ]);

        const insertedId = result.rows[0].id;

        // Create initial salary entry for the new employee
        if (insertedId && employeeData.salary) {
            await employeeModel.createInitialSalaryEntry(insertedId, employeeData.salary, employeeData.tenant_id);
        }

        // Return success response with the inserted ID
        return {
            success: true,
            message: "Employee added successfully",
            employeeId: insertedId
        };
    } catch (error) {
        console.error("Error adding employee:", error);
        
        // Handle unique email constraint violation (PostgreSQL error code)
        if (error.code === '23505') { // PostgreSQL unique violation
            return {
                success: false,
                error: "An employee with this email already exists for this tenant"
            };
        }
        
        // Return generic error message
        return {
            success: false,
            error: error.message || "Failed to add employee"
        };
    }
};

/**
 * Check if an email already exists in the database for a specific tenant
 * @param {string} email - Email to check
 * @param {number} tenantId - Tenant ID for multi-tenant isolation
 * @returns {Promise<boolean>} True if email exists, false otherwise
 */
const checkEmailExists = async (email, tenantId) => {
    try {
        const result = await db.query(
            'SELECT COUNT(*) as count FROM employees WHERE email = $1 AND tenant_id = $2', 
            [email, tenantId]
        );
        return result.rows[0].count > 0;
    } catch (error) {
        console.error("Error checking email existence:", error);
        throw error;
    }
};

module.exports = {
    addEmployee,
    checkEmailExists
};