const db = require("./mainModel");

// Function to get user details by ID
const getUserById = async (userId) => {
    try {
        // First, try tenants table (for business owners)
        const tenantResult = await db.query(`
            SELECT 
                tenant_id as id,
                owner_first_name,
                owner_last_name,
                owner_email as email,
                owner_password as password,
                business_name,
                tagline,
                contact_address,
                phone,
                created_at,
                'owner' as user_type
            FROM tenants 
            WHERE tenant_id = $1
        `, [userId]);
        
        if (tenantResult.rows.length > 0) {
            const owner = tenantResult.rows[0];
            owner.first_name = owner.owner_first_name || '';
            owner.last_name = owner.owner_last_name || '';
            return { success: true, data: owner };
        }
        
        // If not found in tenants, try employees table
        const empResult = await db.query(`
            SELECT 
                id,
                name as first_name,
                '' as last_name,
                email,
                password,
                '' as business_name,
                '' as tagline,
                '' as contact_address,
                '' as phone,
                created_at,
                role as user_type
            FROM employees 
            WHERE id = $1
        `, [userId]);
        
        if (empResult.rows.length === 0) {
            return { success: false, error: "User not found" };
        }
        
        return { success: true, data: empResult.rows[0] };
    } catch (error) {
        console.error("Error fetching user by ID:", error);
        return { success: false, error: error.message };
    }
};

// Function to get user details by email
const getUserByEmail = async (email) => {
    try {
        // First, try tenants table
        const tenantResult = await db.query(`
            SELECT 
                tenant_id as id,
                owner_first_name,
                owner_last_name,
                owner_email as email,
                owner_password as password,
                business_name,
                tagline,
                contact_address,
                phone,
                created_at,
                'owner' as user_type
            FROM tenants 
            WHERE owner_email = $1
        `, [email]);
        
        if (tenantResult.rows.length > 0) {
            const owner = tenantResult.rows[0];
            owner.first_name = owner.owner_first_name || '';
            owner.last_name = owner.owner_last_name || '';
            return { success: true, data: owner };
        }
        
        // If not found in tenants, try employees table
        const empResult = await db.query(`
            SELECT 
                id,
                name as first_name,
                '' as last_name,
                email,
                password,
                '' as business_name,
                '' as tagline,
                '' as contact_address,
                '' as phone,
                created_at,
                role as user_type
            FROM employees 
            WHERE email = $1
        `, [email]);
        
        if (empResult.rows.length === 0) {
            return { success: false, error: "User not found" };
        }
        
        return { success: true, data: empResult.rows[0] };
    } catch (error) {
        console.error("Error fetching user by email:", error);
        return { success: false, error: error.message };
    }
};

// Function to create new user
const createUser = async (userData) => {
    try {
        const { first_name, last_name, email, password, business_name, tagline, contact_address } = userData;
        
        const [result] = await db.query(`
            INSERT INTO user_details (
                first_name, 
                last_name, 
                email, 
                password, 
                business_name, 
                tagline, 
                contact_address
            ) VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [first_name, last_name, email, password, business_name, tagline, contact_address]);
        
        if (result.affectedRows === 0) {
            return { success: false, error: "Failed to create user" };
        }
        
        return { success: true, data: { id: result.insertId, ...userData } };
    } catch (error) {
        console.error("Error creating user:", error);
        return { success: false, error: error.message };
    }
};

// Function to update user profile
const updateUserProfile = async (userId, userData) => {
    try {
        const { first_name, last_name, email } = userData;
        
        const result = await db.query(`
            UPDATE tenants 
            SET 
                owner_first_name = COALESCE($1, owner_first_name),
                owner_last_name = COALESCE($2, owner_last_name),
                owner_email = COALESCE($3, owner_email),
                updated_at = CURRENT_TIMESTAMP
            WHERE tenant_id = $4
            RETURNING tenant_id, owner_first_name, owner_last_name, owner_email, business_name
        `, [first_name, last_name, email, userId]);
        
        if (result.rowCount === 0) {
            return { success: false, error: "User not found or no changes made" };
        }
        
        return { success: true, data: result.rows[0] };
    } catch (error) {
        console.error("Error updating user profile:", error);
        return { success: false, error: error.message };
    }
};

// Function to update business details
const updateBusinessDetails = async (userId, businessData) => {
    try {
        const { business_name, tagline, contact_address, phone } = businessData;
        
        // Update all business-related fields in tenants table
        const result = await db.query(`
            UPDATE tenants 
            SET 
                business_name = COALESCE($1, business_name),
                tagline = COALESCE($2, tagline),
                contact_address = COALESCE($3, contact_address),
                phone = COALESCE($4, phone),
                updated_at = CURRENT_TIMESTAMP
            WHERE tenant_id = $5
            RETURNING tenant_id, business_name, tagline, contact_address, phone
        `, [business_name, tagline, contact_address, phone, userId]);
        
        if (result.rowCount === 0) {
            return { success: false, error: "User not found or no changes made" };
        }
        
        return { success: true, data: result.rows[0] };
    } catch (error) {
        console.error("Error updating business details:", error);
        return { success: false, error: error.message };
    }
};

// Function to update password
const changePassword = async (userId, password) => {
    try {
        const result = await db.query(`
            UPDATE tenants 
            SET owner_password = $1 
            WHERE tenant_id = $2
            RETURNING *
        `, [password, userId]);
        
        if (result.rowCount === 0) {
            return { success: false, error: "User not found or no changes made" };
        }
        
        return { success: true };
    } catch (error) {
        console.error("Error updating password:", error);
        return { success: false, error: error.message };
    }
};

// Function to delete account and all associated data (multi-tenant safe)
const deleteAccount = async (userId, tenantId) => {
    let client = null;
    
    try {
        // Validate inputs
        if (!userId || !tenantId) {
            return { 
                success: false, 
                error: "Invalid user ID or tenant ID provided" 
            };
        }

        // Get database connection
        client = await db.connect();
        
        // Start transaction with isolation level
        await client.query('BEGIN TRANSACTION ISOLATION LEVEL READ COMMITTED');
        
        const deletedRecords = {
            attendance: 0,
            billItems: 0,
            bills: 0,
            inventory: 0,
            finance: 0,
            sales: 0,
            employees: 0,
            tenant: 0
        };
        
        console.log(`Starting account deletion for tenant ${tenantId}`);
        
        // Helper function to safely delete from a table
        const safeDelete = async (tableName, query, params, recordKey) => {
            try {
                const result = await client.query(query, params);
                deletedRecords[recordKey] = result.rowCount;
                console.log(`✓ Deleted ${result.rowCount} records from ${tableName}`);
                return { success: true, count: result.rowCount };
            } catch (error) {
                // If table doesn't exist (42P01) or column doesn't exist (42703), continue
                if (error.code === '42P01' || error.code === '42703') {
                    console.log(`⚠ Table/column in ${tableName} does not exist, skipping...`);
                    deletedRecords[recordKey] = 0;
                    return { success: true, count: 0 };
                }
                // For any other error, throw it
                console.error(`✗ Error deleting from ${tableName}:`, error.message);
                throw new Error(`Failed to delete ${tableName}: ${error.message}`);
            }
        };
        
        // Delete in proper order to respect foreign key constraints
        
        // 1. Delete attendance records
        await safeDelete(
            'attendance_leaves',
            `DELETE FROM attendance_leaves 
             WHERE employee_id IN (
                 SELECT id FROM employees WHERE tenant_id = $1
             ) OR tenant_id = $1`,
            [tenantId],
            'attendance'
        );
        
        // 2. Delete bill items (depends on bills)
        await safeDelete(
            'bill_items',
            `DELETE FROM bill_items 
             WHERE bill_id IN (
                 SELECT bill_id FROM bills WHERE tenant_id = $1
             )`,
            [tenantId],
            'billItems'
        );
        
        // 3. Delete bills
        await safeDelete(
            'bills',
            `DELETE FROM bills WHERE tenant_id = $1`,
            [tenantId],
            'bills'
        );
        
        // 4. Delete inventory items
        await safeDelete(
            'inventory_items',
            `DELETE FROM inventory_items WHERE tenant_id = $1`,
            [tenantId],
            'inventory'
        );
        
        // 5. Delete finance records
        await safeDelete(
            'finance',
            `DELETE FROM finance WHERE tenant_id = $1`,
            [tenantId],
            'finance'
        );
        
        // 6. Delete sales records
        await safeDelete(
            'sales',
            `DELETE FROM sales WHERE tenant_id = $1`,
            [tenantId],
            'sales'
        );
        
        // 7. Delete employees (should be last before tenant)
        await safeDelete(
            'employees',
            `DELETE FROM employees WHERE tenant_id = $1`,
            [tenantId],
            'employees'
        );
        
        // 8. Finally delete the tenant record
        try {
            const tenantResult = await client.query(
                `DELETE FROM tenants WHERE tenant_id = $1 RETURNING tenant_id, business_name`,
                [tenantId]
            );
            
            if (tenantResult.rowCount === 0) {
                throw new Error('Tenant account not found. It may have already been deleted.');
            }
            
            deletedRecords.tenant = tenantResult.rowCount;
            console.log(`✓ Deleted tenant account: ${tenantResult.rows[0].business_name}`);
            
        } catch (error) {
            console.error('✗ Error deleting tenant:', error.message);
            throw new Error(`Failed to delete tenant account: ${error.message}`);
        }
        
        // Commit transaction
        await client.query('COMMIT');
        
        const totalDeleted = Object.values(deletedRecords).reduce((sum, count) => sum + count, 0);
        console.log(`✓ Account deletion completed successfully. Total records deleted: ${totalDeleted}`);
        
        return { 
            success: true, 
            message: "Account and all associated data have been permanently deleted",
            deletedRecords,
            totalRecords: totalDeleted
        };
        
    } catch (error) {
        // Rollback transaction on error
        if (client) {
            try {
                await client.query('ROLLBACK');
                console.log('⚠ Transaction rolled back due to error');
            } catch (rollbackError) {
                console.error('✗ Error during rollback:', rollbackError.message);
            }
        }
        
        console.error("✗ Account deletion failed:", error.message);
        
        return { 
            success: false, 
            error: error.message || "An unexpected error occurred during account deletion"
        };
        
    } finally {
        // Always release the client back to the pool
        if (client) {
            try {
                client.release();
                console.log('Database connection released');
            } catch (releaseError) {
                console.error('Error releasing database connection:', releaseError.message);
            }
        }
    }
};

module.exports = {
    getUserById,
    getUserByEmail,
    createUser,
    updateUserProfile,
    updateBusinessDetails,
    changePassword,
    deleteAccount
};
