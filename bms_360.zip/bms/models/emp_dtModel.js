const db = require("./mainModel");

// Function to fetch employee profile by ID with tenant isolation
const getEmployeeProfile = async (employeeId, tenantId) => {
    try {
        const result = await db.query(`
            SELECT 
                id, 
                name, 
                email, 
                phone, 
                department, 
                salary, 
                date_of_joining, 
                status 
            FROM employees 
            WHERE id = $1 AND tenant_id = $2
        `, [employeeId, tenantId]);
        
        if (result.rows.length === 0) {
            return { success: false, error: "Employee not found" };
        }
        
        return { success: true, data: result.rows[0] };
    } catch (error) {
        console.error("Error fetching employee profile:", error);
        return { success: false, error: error.message };
    }
};

// Function to fetch employee salary details by employee ID with tenant isolation
const getEmployeeSalary = async (employeeId, tenantId) => {
    try {
        const result = await db.query(`
            SELECT 
                id,
                month_year,
                base_salary,
                bonus,
                deductions,
                leave_deduction,
                net_salary,
                final_salary,
                payment_date,
                payment_status,
                notes
            FROM salary_details 
            WHERE employee_id = $1 AND tenant_id = $2
            ORDER BY month_year DESC
        `, [employeeId, tenantId]);
        
        return { success: true, data: result.rows };
    } catch (error) {
        console.error("Error fetching employee salary details:", error);
        return { success: false, error: error.message };
    }
};

// Function to fetch employee attendance details by employee ID with tenant isolation
const getEmployeeAttendance = async (employeeId, tenantId) => {
    try {
        const result = await db.query(`
            SELECT 
                id,
                date,
                status,
                leave_type,
                reason
            FROM attendance_leaves 
            WHERE employee_id = $1 AND tenant_id = $2
            ORDER BY date DESC
            LIMIT 100
        `, [employeeId, tenantId]);
        
        return { success: true, data: result.rows };
    } catch (error) {
        console.error("Error fetching employee attendance details:", error);
        return { success: false, error: error.message };
    }
};

module.exports = {
    getEmployeeProfile,
    getEmployeeSalary,
    getEmployeeAttendance
};
