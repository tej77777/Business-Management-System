const db = require("./mainModel");

/**
 * Billing Model - PostgreSQL Multi-Tenant Support
 * Supports any business type with flexible billing and invoice management
 */

// Function to insert a new bill person data (bills table) for a specific tenant
async function insertBillPersonData(tenantId, billData) {
    const { bill_date, customer_name, customer_phone, customer_age_group, subtotal, gst, discount, grand_total, payment_method } = billData;
    
    const sql = `
        INSERT INTO bills 
        (tenant_id, bill_date, customer_name, customer_phone, customer_age_group, 
         subtotal, gst, discount, grand_total, payment_method, created_at) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, CURRENT_TIMESTAMP)
        RETURNING bill_id
    `;
    
    const params = [tenantId, bill_date, customer_name, customer_phone, customer_age_group, 
                    subtotal, gst, discount, grand_total, payment_method];
    
    try {
        const result = await db.query(sql, params);
        return result.rows[0];
    } catch (error) {
        throw error;
    }
}

// Function to get the last inserted bill ID for a specific tenant
async function getLastInsertedBillId(tenantId) {
    const sql = `
        SELECT bill_id as lastid FROM bills 
        WHERE tenant_id = $1 
        ORDER BY created_at DESC 
        LIMIT 1
    `;
    
    try {
        const result = await db.query(sql, [tenantId]);
        return result.rows[0]?.lastid || null;
    } catch (error) {
        throw error;
    }
}

// Function to insert bill details (bill_items table)
async function insertBillItemData(tenantId, billItemData) {
    const { bill_id, item_code, item_name, item_price, quantity, total } = billItemData;
    
    const sql = `
        INSERT INTO bill_items 
        (tenant_id, bill_id, item_code, item_name, item_price, quantity, total, created_at) 
        VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP)
        RETURNING item_id
    `;
    
    const params = [tenantId, bill_id, item_code, item_name, item_price, quantity, total];
    
    try {
        const result = await db.query(sql, params);
        return result.rows[0];
    } catch (error) {
        throw error;
    }
}

// Function to save a complete bill with its items for a specific tenant
async function saveCompleteBill(tenantId, billData, billItems) {
    const client = await db.connect();
    
    try {
        // Start transaction
        await client.query('BEGIN');
        
        // Insert bill person data
        const billSql = `
            INSERT INTO bills 
            (tenant_id, bill_date, customer_name, customer_phone, customer_age_group, 
             subtotal, gst, discount, grand_total, payment_method, created_at) 
            VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, CURRENT_TIMESTAMP)
            RETURNING bill_id
        `;
        
        const billParams = [
            tenantId,
            billData.bill_date, 
            billData.customer_name, 
            billData.customer_phone, 
            billData.customer_age_group, 
            billData.subtotal, 
            billData.gst, 
            billData.discount, 
            billData.grand_total, 
            billData.payment_method
        ];
        
        const result = await client.query(billSql, billParams);
        const bill_id = result.rows[0].bill_id;
        
        // If no items, commit and return
        if (!billItems || billItems.length === 0) {
            await client.query('COMMIT');
            return { bill_id };
        }
        
        // Insert each bill item
        for (const item of billItems) {
            const itemSql = `
                INSERT INTO bill_items 
                (tenant_id, bill_id, item_code, item_name, item_price, quantity, total, created_at) 
                VALUES ($1, $2, $3, $4, $5, $6, $7, CURRENT_TIMESTAMP)
            `;
            const itemParams = [
                tenantId,
                bill_id,
                item.item_code,
                item.item_name,
                item.item_price,
                item.quantity,
                item.total
            ];
            await client.query(itemSql, itemParams);
        }
        
        // Commit transaction
        await client.query('COMMIT');
        return { bill_id };
    } catch (error) {
        // Rollback in case of error
        await client.query('ROLLBACK');
        throw error;
    } finally {
        client.release();
    }
}

// Get all bills for a specific tenant
async function getAllBills(tenantId, limit = 100, offset = 0) {
    const sql = `
        SELECT * FROM bills 
        WHERE tenant_id = $1 
        ORDER BY created_at DESC 
        LIMIT $2 OFFSET $3
    `;
    
    try {
        const result = await db.query(sql, [tenantId, limit, offset]);
        return result.rows;
    } catch (error) {
        throw error;
    }
}

// Get a specific bill with its items for a tenant
async function getBillById(tenantId, billId) {
    const client = await db.connect();
    
    try {
        // Get bill data
        const billSql = `
            SELECT * FROM bills 
            WHERE tenant_id = $1 AND bill_id = $2
        `;
        const billResult = await client.query(billSql, [tenantId, billId]);
        
        if (billResult.rows.length === 0) {
            return null;
        }
        
        const bill = billResult.rows[0];
        
        // Get bill items
        const itemsSql = `
            SELECT * FROM bill_items 
            WHERE bill_id = $1
            ORDER BY item_id
        `;
        const itemsResult = await client.query(itemsSql, [billId]);
        
        return {
            ...bill,
            items: itemsResult.rows
        };
    } catch (error) {
        throw error;
    } finally {
        client.release();
    }
}

// Search bills by customer name, phone, or date range for a tenant
async function searchBills(tenantId, searchParams) {
    const { customer_name, customer_phone, start_date, end_date, payment_method } = searchParams;
    
    let sql = `SELECT * FROM bills WHERE tenant_id = $1`;
    let params = [tenantId];
    let paramCount = 1;
    
    if (customer_name) {
        paramCount++;
        sql += ` AND customer_name ILIKE $${paramCount}`;
        params.push(`%${customer_name}%`);
    }
    
    if (customer_phone) {
        paramCount++;
        sql += ` AND customer_phone LIKE $${paramCount}`;
        params.push(`%${customer_phone}%`);
    }
    
    if (start_date) {
        paramCount++;
        sql += ` AND bill_date >= $${paramCount}`;
        params.push(start_date);
    }
    
    if (end_date) {
        paramCount++;
        sql += ` AND bill_date <= $${paramCount}`;
        params.push(end_date);
    }
    
    if (payment_method) {
        paramCount++;
        sql += ` AND payment_method = $${paramCount}`;
        params.push(payment_method);
    }
    
    sql += ` ORDER BY created_at DESC`;
    
    try {
        const result = await db.query(sql, params);
        return result.rows;
    } catch (error) {
        throw error;
    }
}

// Get billing statistics for a specific tenant
async function getBillingStats(tenantId, startDate = null, endDate = null) {
    let sql = `
        SELECT 
            COUNT(*) as total_bills,
            SUM(grand_total) as total_revenue,
            SUM(subtotal) as total_subtotal,
            SUM(gst) as total_gst,
            SUM(discount) as total_discount,
            AVG(grand_total) as average_bill_value,
            COUNT(DISTINCT customer_phone) as unique_customers
        FROM bills 
        WHERE tenant_id = $1
    `;
    
    let params = [tenantId];
    let paramCount = 1;
    
    if (startDate) {
        paramCount++;
        sql += ` AND bill_date >= $${paramCount}`;
        params.push(startDate);
    }
    
    if (endDate) {
        paramCount++;
        sql += ` AND bill_date <= $${paramCount}`;
        params.push(endDate);
    }
    
    try {
        const result = await db.query(sql, params);
        return result.rows[0];
    } catch (error) {
        throw error;
    }
}

// Get payment method breakdown for a tenant
async function getPaymentMethodStats(tenantId, startDate = null, endDate = null) {
    let sql = `
        SELECT 
            payment_method,
            COUNT(*) as count,
            SUM(grand_total) as total_amount
        FROM bills 
        WHERE tenant_id = $1
    `;
    
    let params = [tenantId];
    let paramCount = 1;
    
    if (startDate) {
        paramCount++;
        sql += ` AND bill_date >= $${paramCount}`;
        params.push(startDate);
    }
    
    if (endDate) {
        paramCount++;
        sql += ` AND bill_date <= $${paramCount}`;
        params.push(endDate);
    }
    
    sql += ` GROUP BY payment_method ORDER BY total_amount DESC`;
    
    try {
        const result = await db.query(sql, params);
        return result.rows;
    } catch (error) {
        throw error;
    }
}

// Delete a bill and its items for a tenant
async function deleteBill(tenantId, billId) {
    const client = await db.connect();
    
    try {
        await client.query('BEGIN');
        
        // Verify bill belongs to tenant
        const checkSql = `SELECT bill_id FROM bills WHERE tenant_id = $1 AND bill_id = $2`;
        const checkResult = await client.query(checkSql, [tenantId, billId]);
        
        if (checkResult.rows.length === 0) {
            throw new Error('Bill not found or access denied');
        }
        
        // Delete bill items first
        await client.query('DELETE FROM bill_items WHERE bill_id = $1', [billId]);
        
        // Delete bill
        await client.query('DELETE FROM bills WHERE bill_id = $1', [billId]);
        
        await client.query('COMMIT');
        return { success: true };
    } catch (error) {
        await client.query('ROLLBACK');
        throw error;
    } finally {
        client.release();
    }
}

// Get top customers for a tenant
async function getTopCustomers(tenantId, limit = 10) {
    const sql = `
        SELECT 
            customer_name,
            customer_phone,
            COUNT(*) as total_bills,
            SUM(grand_total) as total_spent,
            AVG(grand_total) as average_spent
        FROM bills 
        WHERE tenant_id = $1 AND customer_name IS NOT NULL
        GROUP BY customer_name, customer_phone
        ORDER BY total_spent DESC
        LIMIT $2
    `;
    
    try {
        const result = await db.query(sql, [tenantId, limit]);
        return result.rows;
    } catch (error) {
        throw error;
    }
}

// function to export 
module.exports = {
    insertBillPersonData,
    insertBillItemData,
    getLastInsertedBillId,
    saveCompleteBill,
    getAllBills,
    getBillById,
    searchBills,
    getBillingStats,
    getPaymentMethodStats,
    deleteBill,
    getTopCustomers
};