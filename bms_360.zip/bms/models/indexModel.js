const db = require("./mainModel");

// function for Total Sales Today
const getTotalSalesToday = async (tenant_id) => {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    const sql = `SELECT COALESCE(SUM(grand_total), 0) AS total_sales 
                FROM bills 
                WHERE DATE(bill_date) = $1 
                  AND tenant_id = $2`;
    const results = await db.query(sql, [today, tenant_id]);
    // Format as a number and ensure it's not null
    return parseFloat(results.rows[0]?.total_sales || 0);
};

// function for Bills Made Today
const getBillsMadeToday = async (tenant_id) => {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    const sql = `SELECT COUNT(bill_id) AS bill_count 
                FROM bills 
                WHERE DATE(bill_date) = $1
                  AND tenant_id = $2`;
    const results = await db.query(sql, [today, tenant_id]);
    // Ensure we return a numeric value, not null
    return parseInt(results.rows[0]?.bill_count || 0);
};

// function for Items Sold Today
const getItemsSoldToday = async (tenant_id) => {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    // First check if the bill_items table has the bill_id column
    const sql = `SELECT 
                    COALESCE(SUM(bi.quantity), 0) AS items_sold
                FROM 
                    bill_items bi
                    INNER JOIN bills b ON bi.bill_id = b.bill_id AND bi.tenant_id = b.tenant_id
                WHERE 
                    DATE(b.bill_date) = $1
                    AND b.tenant_id = $2`;
    
    try {
        const results = await db.query(sql, [today, tenant_id]);
        // Ensure we return a numeric value, not null
        return parseInt(results.rows[0]?.items_sold || 0);
    } catch (error) {
        console.error("Error in getItemsSoldToday:", error.message);
        return 0;
    }
};

// function for Cash in Hand
const getCashInHand = async (tenant_id) => {
    const sql = `
        SELECT COALESCE(SUM(grand_total), 0) AS cash_in_hand
        FROM bills
        WHERE payment_method IN ('Cash', 'UPI')
          AND tenant_id = $1;
    `;
    const result = await db.query(sql, [tenant_id]);
    return parseFloat(result.rows[0]?.cash_in_hand) || 0;
};

// function for Expenses Today
const getExpensesToday = async (tenant_id) => {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    const sql = `SELECT COALESCE(SUM(amount), 0) AS total_expenses
                FROM maintenance_expenses
                WHERE DATE(entry_date) = $1
                  AND tenant_id = $2`;
    const results = await db.query(sql, [today, tenant_id]);
    return parseFloat(results.rows[0]?.total_expenses || 0);
};

// function for Pending Customer Khata
const getPendingCustomerKhata = async (tenant_id) => {
    // Get credit payments from bills table
    const sql = `SELECT COALESCE(SUM(grand_total), 0) AS total_pending
                FROM bills
                WHERE payment_method = 'Credit'
                  AND tenant_id = $1`;
    const results = await db.query(sql, [tenant_id]);
    return parseFloat(results.rows[0]?.total_pending || 0);
};

// function for Low Stock Items
const getLowStockItems = async (tenant_id, threshold = 10) => {
    const sql = `SELECT COUNT(*) AS low_stock_count
                FROM inventory_items
                WHERE stock_qty > 0 
                  AND stock_qty <= $1
                  AND tenant_id = $2`;
    const results = await db.query(sql, [threshold, tenant_id]);
    return parseInt(results.rows[0]?.low_stock_count) || 0;
};

// function for New Stock Added (Today)
const getNewStockAddedToday = async (tenant_id) => {
    const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
    
    try {
        // Count items created today
        const newItemsSql = `SELECT COUNT(*) AS new_items_count
                    FROM inventory_items
                    WHERE DATE(created_at) = $1
                      AND tenant_id = $2`;
        const newItemsResults = await db.query(newItemsSql, [today, tenant_id]);
        
        // Count items with updated stock today
        const updatedStockSql = `SELECT COUNT(*) AS updated_items_count
                        FROM inventory_items
                        WHERE DATE(updated_at) = $1 
                        AND DATE(updated_at) <> DATE(created_at)
                        AND tenant_id = $2`;
        const updatedStockResults = await db.query(updatedStockSql, [today, tenant_id]);
        
        // Sum both counts
        const totalNewStock = parseInt(newItemsResults.rows[0]?.new_items_count || 0) + 
                              parseInt(updatedStockResults.rows[0]?.updated_items_count || 0);
        
        return totalNewStock;
    } catch (error) {
        console.error("Error in getNewStockAddedToday:", error);
        return 0;
    }
};

// function for Out of Stock Products
const getOutOfStockProducts = async (tenant_id) => {
    const sql = `SELECT COUNT(*) AS out_of_stock_count
                FROM inventory_items
                WHERE stock_qty = 0
                  AND tenant_id = $1`;
    const results = await db.query(sql, [tenant_id]);
    return parseInt(results.rows[0]?.out_of_stock_count) || 0;
};

// Export all functions
module.exports = {
    getTotalSalesToday,
    getBillsMadeToday,
    getItemsSoldToday,
    getCashInHand,
    getExpensesToday,
    getPendingCustomerKhata,
    getLowStockItems,
    getNewStockAddedToday,
    getOutOfStockProducts
};