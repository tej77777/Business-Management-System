const express = require('express');
const path = require('path');
const fs = require('fs');
const helmet = require('helmet');
const compression = require('compression');
const cors = require('cors');
const session = require('express-session');
const pgSession = require('connect-pg-simple')(session);
const xss = require('xss');
const config = require('./config/config');
const { logger } = require('./utils/logger');
const db = require('./models/mainModel'); // PostgreSQL pool

// Initialize Express app
const app = express();

// Basic security headers
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com", "https://cdnjs.cloudflare.com", "https://cdn.jsdelivr.net"],
            fontSrc: ["'self'", "https://fonts.gstatic.com", "https://cdnjs.cloudflare.com", "https://cdn.jsdelivr.net"],
            scriptSrc: ["'self'", "'unsafe-inline'", "https://code.jquery.com", "https://cdn.jsdelivr.net", "https://cdnjs.cloudflare.com"],
            imgSrc: ["'self'", "data:", "https:"],
        }
    }
}));

// Enable CORS with credentials
app.use(cors({
    origin: config.cors.origin,
    credentials: true
}));

// Enable compression
app.use(compression());

// Body parsing middleware
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// XSS Protection Middleware - Sanitize all user inputs
app.use((req, res, next) => {
    const sanitizeObject = (obj) => {
        if (!obj || typeof obj !== 'object') return obj;
        
        for (let key in obj) {
            if (typeof obj[key] === 'string') {
                // Clean XSS attacks from string inputs
                obj[key] = xss(obj[key]);
            } else if (typeof obj[key] === 'object' && obj[key] !== null) {
                sanitizeObject(obj[key]);
            }
        }
        return obj;
    };

    // Sanitize request body, query params, and URL params
    if (req.body) req.body = sanitizeObject(req.body);
    if (req.query) req.query = sanitizeObject(req.query);
    if (req.params) req.params = sanitizeObject(req.params);
    
    next();
});

// Session configuration for multi-tenant authentication
// Sessions stored in PostgreSQL - survives server restarts
app.use(session({
    store: new pgSession({
        pool: db, // Use existing PostgreSQL connection pool
        tableName: 'session', // Table name for sessions
        createTableIfMissing: true, // Auto-create table on first run
        pruneSessionInterval: 60 * 15 // Clean up expired sessions every 15 minutes
    }),
    secret: config.security.sessionSecret,
    resave: false,
    saveUninitialized: false,
    cookie: {
        secure: config.security.httpsEnabled, // Use HTTPS in production
        httpOnly: true,
        maxAge: config.security.sessionTimeout,
        sameSite: 'lax'
    },
    name: 'bms360.sid' // Custom session ID name
}));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Make user available to all views
app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    next();
});

// Static file serving with security headers (MUST be before routes)
const staticOptions = {
    dotfiles: 'deny',
    index: false,
    maxAge: config.app.env === 'production' ? '1d' : '0',
    setHeaders: (res, path) => {
        // Security headers for static files
        res.setHeader('X-Content-Type-Options', 'nosniff');
        if (path.endsWith('.js')) {
            res.setHeader('Content-Type', 'application/javascript');
        } else if (path.endsWith('.css')) {
            res.setHeader('Content-Type', 'text/css');
        }
    }
};

// Serve static files
if (fs.existsSync(path.join(__dirname, 'public'))) {
    app.use(express.static(path.join(__dirname, 'public'), staticOptions));
}
app.use('/assets', express.static(path.join(__dirname, 'views/assets'), staticOptions));

// Route imports
const authRoute = require('./routes/auth');
const indexroute = require('./routes/index');
const billingroute = require('./routes/billing');
const employeeroute = require('./routes/employee');
const inventoryroute = require('./routes/inventory');
const financeroute = require('./routes/finance');
const salesroute = require('./routes/sales');
const newEmproute = require('./routes/new_emp');
const empDtRoute = require('./routes/emp_dt');
const attEmpRoute = require('./routes/att_emp');
const profileRoute = require('./routes/profile');

// Route registration
app.use('/auth', authRoute); // Authentication routes (public)
app.use('/', indexroute);
app.use('/billing', billingroute);
app.use('/employee', employeeroute);
app.use('/finance', financeroute);
app.use('/inventory', inventoryroute);
app.use('/sales', salesroute);
app.use('/new_emp', newEmproute);
app.use('/emp_dt', empDtRoute);
app.use('/att_emp', attEmpRoute);
app.use('/profile', profileRoute);

// Health check endpoint (useful for Render/deployment monitoring)
app.get('/health', (req, res) => {
    res.status(200).json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        environment: config.app.env,
        version: process.env.npm_package_version || '1.0.0',
        uptime: process.uptime()
    });
});

// Global error handler
app.use((err, req, res, next) => {
    logger.error('Global error:', {
        error: err.message,
        stack: err.stack,
        url: req.originalUrl,
        method: req.method,
        ip: req.ip,
        userId: req.session?.user?.id
    });

    // Don't expose error details in production
    const errorDetails = config.app.env === 'production' 
        ? { message: 'Something went wrong', status: 500 }
        : { message: err.message, status: err.status || 500, stack: err.stack };

    res.status(err.status || 500).render('error', {
        message: errorDetails.message,
        error: errorDetails
    });
});

// Handle 404 errors
app.use((req, res) => {
    logger.warn('404 Not Found:', {
        url: req.originalUrl,
        method: req.method,
        ip: req.ip,
        userAgent: req.get('User-Agent')
    });

    res.status(404).render('error', {
        message: 'Page not found',
        error: { status: 404 }
    });
});

// Graceful shutdown handling
process.on('SIGTERM', () => {
    logger.info('SIGTERM received, shutting down gracefully');
    process.exit(0);
});

process.on('SIGINT', () => {
    logger.info('SIGINT received, shutting down gracefully');
    process.exit(0);
});

// Start server
const server = app.listen(config.app.port, () => {
    logger.info(`🚀 ${config.app.name} server started`, {
        port: config.app.port,
        environment: config.app.env,
        httpsEnabled: config.security.httpsEnabled,
        timestamp: new Date().toISOString()
    });
});

// Handle server errors
server.on('error', (error) => {
    if (error.code === 'EADDRINUSE') {
        logger.error(`Port ${config.app.port} is already in use`);
    } else {
        logger.error('Server error:', error);
    }
    process.exit(1);
});

module.exports = app;
