const express = require('express');
const router = express.Router();
const billing = require('../controllers/billing_control');
const { requireAuth, requireDepartment } = require('../middleware/auth');

// All billing routes require authentication
// Billing can be accessed by owner, admin, and billing role
router.get('/', requireAuth, requireDepartment('Billing'), billing.getbilling);
router.post('/', requireAuth, requireDepartment('Billing'), billing.postBilling);
router.post('/generate-pdf', requireAuth, requireDepartment('Billing'), billing.generatePDF);
router.get('/api/business-details', requireAuth, requireDepartment('Billing'), billing.getBusinessDetails);

module.exports = router;
