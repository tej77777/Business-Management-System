const express = require('express');
const router = express.Router();
const emp_dt_controller = require('../controllers/emp_dt_control');
const { requireAuth } = require('../middleware/auth');

// All routes require authentication

// Route to show employee details page
router.get('/:id', requireAuth, emp_dt_controller.getEmployeeDetails);

module.exports = router;
