const express = require('express');
const router = express.Router();
const finance = require('../controllers/finance_control');
const { requireAuth, requireDepartment } = require('../middleware/auth');

// All routes require authentication
// Finance can be accessed by owner, admin, and finance role

// Main finance dashboard
router.get('/', requireAuth, requireDepartment('Finance'), finance.getfinance);

// API routes for finance data
router.get('/api/salary-details', requireAuth, requireDepartment('Finance'), finance.getSalaryDetails);

// Maintenance Expenses routes
router.post('/api/maintenance-expenses', requireAuth, requireDepartment('Finance'), finance.addMaintenanceExpense);
router.get('/api/maintenance-expenses', requireAuth, requireDepartment('Finance'), finance.getAllMaintenanceExpenses);
router.get('/api/today-expenses', requireAuth, requireDepartment('Finance'), finance.getTodayExpensesDetails);

// All Expenses Details route
router.get('/api/all-expenses-details', requireAuth, requireDepartment('Finance'), finance.getAllExpensesDetails);

// Supplier Khata routes
router.post('/api/supplier-khata', requireAuth, requireDepartment('Finance'), finance.addSupplierKhata);
router.get('/api/supplier-khata', requireAuth, requireDepartment('Finance'), finance.getAllSupplierKhata);
router.post('/api/supplier-khata/clear-all', requireAuth, requireDepartment('Finance'), finance.clearAllSupplierKhata);
router.post('/api/supplier-khata/:id/pay', requireAuth, requireDepartment('Finance'), finance.paySupplierKhata);

// Customer Khata routes
router.get('/api/customer-khata', requireAuth, requireDepartment('Finance'), finance.getCustomerKhataDetails);
router.post('/api/customer-khata/payment', requireAuth, requireDepartment('Finance'), finance.updateBillPaymentMethod);

module.exports = router;
