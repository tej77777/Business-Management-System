const express = require('express');
const router = express.Router();
const employee = require('../controllers/employee_control');
const { requireAuth, requireDepartment } = require('../middleware/auth');

// All routes require authentication
// Employee management requires owner or admin role

// Route for employee page - now using EJS template with data
router.get('/', requireAuth, requireDepartment('HR'), employee.getemployee);

// Route to redirect /employee/add to /new_emp for backward compatibility
router.get('/add', requireAuth, (req, res) => {
    res.redirect('/new_emp');
});

// Route to get employee details by ID
router.get('/details/:id', requireAuth, employee.getEmployeeById);

// Route to render edit employee form
router.get('/edit/:id', requireAuth, requireDepartment('HR'), employee.renderEditEmployeeForm);

// Route to update employee
router.post('/update/:id', requireAuth, requireDepartment('HR'), employee.updateEmployee);

// Route to delete employee
router.delete('/delete/:id', requireAuth, requireDepartment('HR'), employee.deleteEmployee);

// Route to get list of all employees (basic info for dropdowns)
router.get('/list', requireAuth, requireDepartment('HR'), employee.getAllEmployeesBasic);

// Salary management routes
router.get('/salary/list', employee.getAllSalaryRecords);
router.get('/salary/:id', employee.getSalaryById);
router.post('/salary', employee.createSalaryRecord);
router.put('/salary/:id', employee.updateSalaryRecord);
router.post('/salary/:id/pay', employee.markSalaryAsPaid);

module.exports = router;
