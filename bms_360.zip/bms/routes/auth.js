const express = require('express');
const router = express.Router();
const authController = require('../controllers/auth_control');
const { requireAuth, requireOwner } = require('../middleware/auth');

/**
 * Authentication Routes
 * Multi-tenant authentication for business owners and employees
 */

// Public routes (no authentication required)

// Show registration page
router.get('/register', authController.showRegisterPage);

// Show login page
router.get('/login', authController.showLoginPage);

// Register new tenant (business owner)
router.post('/register', authController.registerTenant);

// Login for tenants (business owners)
router.post('/login/tenant', authController.loginTenant);

// Login for employees
router.post('/login/employee', authController.loginEmployee);

// Check authentication status
router.get('/check', authController.checkAuth);

// Protected routes (authentication required)

// Logout
router.post('/logout', requireAuth, authController.logout);

// Alternative logout route (GET)
router.get('/logout', requireAuth, authController.logout);

module.exports = router;
