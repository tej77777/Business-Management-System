const express = require('express');
const router = express.Router();
const profileController = require('../controllers/profile_control');
const { requireAuth, requireOwner } = require('../middleware/auth');
const { body } = require('express-validator');

// All routes require authentication and owner privileges
// Profile management is for business owners only

// Route to serve profile.html
router.get('/', requireAuth, requireOwner, profileController.showProfile);

// API routes for profile operations

// Get user profile data
router.get('/data', requireAuth, requireOwner, profileController.getUserProfile);

// Update personal information
router.post('/update-personal', requireAuth, requireOwner, [
    body('firstName').optional().trim().isLength({ min: 1 }).withMessage('First name cannot be empty'),
    body('lastName').optional().trim().isLength({ min: 1 }).withMessage('Last name cannot be empty'),
    body('first_name').optional().trim().isLength({ min: 1 }).withMessage('First name cannot be empty'),
    body('last_name').optional().trim().isLength({ min: 1 }).withMessage('Last name cannot be empty'),
    body('email').optional().isEmail().normalizeEmail().withMessage('Valid email is required')
], profileController.updateUserProfile);

// Update business details
router.post('/update-business', requireAuth, requireOwner, [
    body('businessName').trim().isLength({ min: 1 }).withMessage('Business name is required')
], profileController.updateBusinessDetails);

// Change password
router.post('/change-password', requireAuth, requireOwner, [
    body('currentPassword').notEmpty().withMessage('Current password is required'),
    body('newPassword').isLength({ min: 8 }).withMessage('Password must be at least 8 characters long')
], profileController.changePassword);

// Delete account (requires password confirmation)
router.post('/delete-account', requireAuth, requireOwner, [
    body('password').notEmpty().withMessage('Password is required')
], profileController.deleteAccount);

// Legacy API routes (for backward compatibility)
router.get('/api/user', requireAuth, requireOwner, profileController.getUserProfile);
router.post('/api/user', requireAuth, requireOwner, profileController.updateUserProfile);
router.get('/api/business', requireAuth, requireOwner, profileController.getUserProfile);
router.post('/api/business', requireAuth, requireOwner, profileController.updateBusinessDetails);
router.post('/api/change-password', requireAuth, requireOwner, profileController.changePassword);

module.exports = router;
