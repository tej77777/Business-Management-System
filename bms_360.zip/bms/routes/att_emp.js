const express = require('express');
const router = express.Router();
const AttendanceController = require('../controllers/att_emp_control');
const { requireAuth, requireDepartment } = require('../middleware/auth');

// All routes require authentication
// Attendance can be accessed by owner, admin, and manager

// GET attendance page
router.get('/', requireAuth, requireDepartment('HR'), AttendanceController.getAttendancePage);

// Save attendance record
router.post('/save', requireAuth, requireDepartment('HR'), AttendanceController.saveAttendance);

module.exports = router;
