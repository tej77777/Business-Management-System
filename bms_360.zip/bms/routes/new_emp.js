const express = require('express');
const router = express.Router();
const newEmpController = require('../controllers/new_emp_control');
const { requireAuth, requireDepartment } = require('../middleware/auth');

// All routes require authentication
// Employee management requires owner or admin role

// Route to render the add employee form
router.get('/', requireAuth, requireDepartment('HR'), newEmpController.renderAddEmployeePage);

// Route to handle adding a new employee
router.post('/add', requireAuth, requireDepartment('HR'), newEmpController.addNewEmployee);

module.exports = router;