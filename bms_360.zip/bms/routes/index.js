const express = require('express');
const router = express.Router();
const index = require('../controllers/index_control');
const { requireAuth, requireOwner } = require('../middleware/auth');

// Dashboard route - requires authentication and owner privileges
// Main dashboard is for business owners only
router.get('/', requireAuth, requireOwner, index.getindex);

module.exports = router;
