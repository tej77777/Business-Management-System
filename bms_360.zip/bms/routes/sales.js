const express = require('express');
const router = express.Router();
const sales = require('../controllers/sales_control');
const { requireAuth, requireDepartment } = require('../middleware/auth');

// All routes require authentication
// Sales can be accessed by owner, admin, and sales role

// Main dashboard route: renders sales.ejs with all metrics
router.get('/', requireAuth, requireDepartment('Sales'), async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        
        const [
            totalProfit,
            totalSales,
            numberOfBills,
            paymentTypeSplits,
            top5Products,
            bottom5Products,
            cashInHand,
            categorySales,
            ageGroupTrends,
            customerLoyaltyData,
            averageBasketSize,
            paymentPreferences
        ] = await Promise.all([
            sales.totalProfitRaw(tenant_id),
            sales.totalSalesRaw(tenant_id),
            sales.numberOfBillsRaw(tenant_id),
            sales.paymentTypeSplitsRaw(tenant_id),
            sales.top5ProductsRaw(tenant_id),
            sales.bottom5ProductsRaw(tenant_id),
            sales.cashInHandRaw(tenant_id),
            sales.categorySalesRaw(tenant_id),
            sales.ageGroupTrendsRaw(tenant_id),
            sales.customerLoyaltyDataRaw(tenant_id),
            sales.averageBasketSizeRaw(tenant_id),
            sales.paymentPreferencesRaw(tenant_id)
        ]);
        res.render('sales', {
            user: req.session.user,
            totalProfit,
            totalSales,
            numberOfBills,
            paymentTypeSplits,
            top5Products,
            bottom5Products,
            cashInHand,
            categorySales,
            ageGroupTrends,
            customerLoyaltyData,
            averageBasketSize,
            paymentPreferences
        });
    } catch (err) {
        res.status(500).send('Error loading sales dashboard: ' + err.message);
    }
});

// API endpoints for each metric (optional, keep if needed)
router.get('/total-profit', requireAuth, requireDepartment('Sales'), sales.totalProfit);
router.get('/total-sales', sales.totalSales);
router.get('/number-of-bills', sales.numberOfBills);
router.get('/payment-type-splits', sales.paymentTypeSplits);
router.get('/top5-products', sales.top5Products);
router.get('/bottom5-products', sales.bottom5Products);
router.get('/cash-in-hand', sales.cashInHand);
router.get('/category-sales', sales.categorySales);

// API endpoints for customer behavior analysis
router.get('/age-group-trends', sales.ageGroupTrends);
router.get('/customer-loyalty-data', sales.customerLoyaltyData);
router.get('/average-basket-size', sales.averageBasketSize);
router.get('/payment-preferences', sales.paymentPreferences);

module.exports = router;
