const { logger } = require('../utils/logger');

/**
 * Authentication Middleware
 * Provides session-based authentication and authorization
 * 
 * ACCESS CONTROL SYSTEM:
 * - Department-based access: Access is controlled by user's 'department' field
 * - Owner bypass: Business owners (isOwner: true) have access to ALL departments
 * - Role field: Used for job title/hierarchy only (e.g., 'manager', 'employee')
 * 
 * Available Departments: Finance, HR, Sales, Inventory, Billing
 */

/**
 * Require authentication
 * Ensures user is logged in
 */
const requireAuth = (req, res, next) => {
    if (req.session && req.session.user) {
        // User is authenticated
        res.locals.user = req.session.user;
        return next();
    }

    // Not authenticated
    if (req.xhr || req.headers.accept?.indexOf('json') > -1) {
        // API request - return JSON
        return res.status(401).json({
            success: false,
            message: 'Authentication required',
            redirect: '/auth/login'
        });
    } else {
        // Browser request - redirect to login
        return res.redirect('/auth/login');
    }
};

/**
 * Require business owner (tenant) role
 * Only allows access to tenant owners
 */
const requireOwner = (req, res, next) => {
    if (!req.session || !req.session.user) {
        if (req.xhr || req.headers.accept?.indexOf('json') > -1) {
            return res.status(401).json({
                success: false,
                message: 'Authentication required'
            });
        } else {
            return res.redirect('/auth/login');
        }
    }

    if (req.session.user.isOwner) {
        return next();
    }

    // Not authorized
    logger.warn(`Unauthorized access attempt by user ${req.session.user.email} to owner-only resource`);
    
    if (req.xhr || req.headers.accept?.indexOf('json') > -1) {
        return res.status(403).json({
            success: false,
            message: 'Access denied. Owner privileges required.'
        });
    } else {
        return res.status(403).render('error', {
            message: 'Access Denied',
            error: { status: 403, stack: 'You do not have permission to access this resource.' }
        });
    }
};

/**
 * Require department-based access
 * Usage: requireDepartment('Finance')
 * Allows access if user is in the given department
 * Owner has full access to all departments
 */
const requireDepartment = (...departments) => {
    return (req, res, next) => {
        if (!req.session || !req.session.user) {
            if (req.xhr || req.headers.accept?.indexOf('json') > -1) {
                return res.status(401).json({
                    success: false,
                    message: 'Authentication required'
                });
            } else {
                return res.redirect('/auth/login');
            }
        }

        const userDept = req.session.user.department;

        // Owner has access to everything
        if (req.session.user.isOwner) {
            return next();
        }

        // Check if user's department matches any of the required departments (case-insensitive)
        for (const d of departments) {
            if (userDept && userDept.toLowerCase() === d.toLowerCase()) {
                return next();
            }
        }

        // Not authorized
        logger.warn(`Unauthorized access attempt by user ${req.session.user.email} (dept: ${userDept}) to resource requiring departments: ${departments.join(', ')}`);

        if (req.xhr || req.headers.accept?.indexOf('json') > -1) {
            return res.status(403).json({
                success: false,
                message: `Access denied. Required department: ${departments.join(' or ')}`
            });
        } else {
            return res.status(403).render('error', {
                message: 'Access Denied',
                error: { status: 403, stack: 'You do not have permission to access this resource.' }
            });
        }
    };
};

/**
 * Optional authentication
 * Adds user to request if authenticated, but doesn't require it
 */
const optionalAuth = (req, res, next) => {
    if (req.session && req.session.user) {
        res.locals.user = req.session.user;
    }
    next();
};

/**
 * Check if user is authenticated (for AJAX requests)
 */
const isAuthenticated = (req) => {
    return !!(req.session && req.session.user);
};

/**
 * Check if user is owner (for AJAX requests)
 */
const isOwner = (req) => {
    return !!(req.session && req.session.user && req.session.user.isOwner);
};

/**
 * Check if user has access to specific department (for AJAX requests)
 */
const hasDepartmentAccess = (req, department) => {
    if (!req.session || !req.session.user) return false;
    // Owner has access to all departments
    if (req.session.user.isOwner) return true;
    // Check if user's department matches (case-insensitive)
    return req.session.user.department && 
           req.session.user.department.toLowerCase() === department.toLowerCase();
};

module.exports = {
    requireAuth,
    requireOwner,
    requireDepartment,
    optionalAuth,
    isAuthenticated,
    isOwner,
    hasDepartmentAccess
};
