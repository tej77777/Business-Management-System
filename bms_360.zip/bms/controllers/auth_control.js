const bcrypt = require('bcrypt');
const { logger } = require('../utils/logger');
const authModel = require('../models/authModel');
const { createTenant } = require('../utils/tenantHelper');

/**
 * Multi-Tenant Authentication Controller
 * Handles registration, login, logout for business owners and employees
 */

/**
 * Show registration page
 */
const showRegisterPage = (req, res) => {
    try {
        res.sendFile('register.html', { root: './views' });
    } catch (error) {
        logger.error('Error showing register page:', error);
        res.status(500).send('Server error');
    }
};

/**
 * Show login page
 */
const showLoginPage = (req, res) => {
    try {
        res.sendFile('login.html', { root: './views' });
    } catch (error) {
        logger.error('Error showing login page:', error);
        res.status(500).send('Server error');
    }
};

/**
 * Register new business owner (Tenant)
 * Creates a new tenant account with isolated data space
 */
const registerTenant = async (req, res) => {
    try {
        const {
            first_name,
            last_name,
            business_name,
            email,
            password,
            business_contact,
            business_address,
            tagline
        } = req.body;

        // Validate required fields
        if (!first_name || !business_name || !email || !password || !business_contact) {
            return res.status(400).json({
                success: false,
                message: 'Please provide all required fields (name, business name, email, password, and phone number)'
            });
        }

        // Validate phone number
        if (business_contact.trim().length < 10) {
            return res.status(400).json({
                success: false,
                message: 'Please provide a valid phone number (minimum 10 digits)'
            });
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid email format'
            });
        }

        // Validate password strength
        if (password.length < 8) {
            return res.status(400).json({
                success: false,
                message: 'Password must be at least 8 characters long'
            });
        }

        // Check if email already exists
        const existingTenant = await authModel.findTenantByEmail(email);
        if (existingTenant) {
            return res.status(409).json({
                success: false,
                message: 'Email already registered. Please login instead.'
            });
        }

        // Hash password
        const saltRounds = 12;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        // Create new tenant
        const tenantData = {
            business_name,
            owner_first_name: first_name,
            owner_last_name: last_name || '',
            owner_email: email,
            owner_password: hashedPassword,
            tagline: tagline || '',
            contact_address: business_address || '',
            phone: business_contact || '',
            subscription_plan: 'trial', // Start with trial
            subscription_status: 'active',
            trial_ends_at: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days trial
        };

        const newTenant = await authModel.createTenant(tenantData);

        // Log successful registration
        logger.info(`New tenant registered: ${email} - Business: ${business_name}`);

        res.status(201).json({
            success: true,
            message: 'Registration successful! You can now login.',
            tenant_id: newTenant.tenant_id
        });

    } catch (error) {
        logger.error('Registration error:', error);
        res.status(500).json({
            success: false,
            message: 'Registration failed. Please try again later.'
        });
    }
};

/**
 * Login for business owners (Tenants)
 */
const loginTenant = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Validate input
        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Please provide email and password'
            });
        }

        // Find tenant by email
        const tenant = await authModel.findTenantByEmail(email);
        
        if (!tenant) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }

        // Check if account is active
        if (!tenant.is_active) {
            return res.status(403).json({
                success: false,
                message: 'Your account has been deactivated. Please contact support.'
            });
        }

        // Check if account is locked
        if (tenant.locked_until && new Date(tenant.locked_until) > new Date()) {
            const remainingTime = Math.ceil((new Date(tenant.locked_until) - new Date()) / 60000);
            return res.status(403).json({
                success: false,
                message: `Account is locked. Please try again in ${remainingTime} minutes.`
            });
        }

        // Verify password
        const isPasswordValid = await bcrypt.compare(password, tenant.owner_password);
        
        if (!isPasswordValid) {
            // Increment login attempts
            await authModel.incrementLoginAttempts(tenant.tenant_id, 'tenant');
            
            // Check if we should lock the account
            const updatedTenant = await authModel.findTenantByEmail(email);
            if (updatedTenant.login_attempts >= 5) {
                // Lock account for 15 minutes
                await authModel.lockAccount(tenant.tenant_id, 15, 'tenant');
                return res.status(403).json({
                    success: false,
                    message: 'Too many failed login attempts. Account locked for 15 minutes.'
                });
            }

            return res.status(401).json({
                success: false,
                message: 'Invalid email or password',
                remaining_attempts: 5 - updatedTenant.login_attempts
            });
        }

        // Check subscription status
        if (tenant.subscription_status !== 'active') {
            return res.status(403).json({
                success: false,
                message: 'Your subscription is not active. Please renew your subscription.'
            });
        }

        // Reset login attempts on successful login
        await authModel.resetLoginAttempts(tenant.tenant_id, 'tenant');

        // Update last login info
        const clientIp = req.ip || req.connection.remoteAddress;
        await authModel.updateLastLogin(tenant.tenant_id, clientIp, 'tenant');

        // Create session
        req.session.user = {
            id: tenant.tenant_id,
            tenant_id: tenant.tenant_id,
            name: `${tenant.owner_first_name} ${tenant.owner_last_name}`,
            email: tenant.owner_email,
            business_name: tenant.business_name,
            role: 'owner',
            isOwner: true,
            subscription_plan: tenant.subscription_plan,
            subscription_status: tenant.subscription_status
        };

        // Log successful login
        logger.info(`Tenant login successful: ${email} from IP: ${clientIp}`);

        res.json({
            success: true,
            message: 'Login successful!',
            user: {
                name: req.session.user.name,
                email: req.session.user.email,
                business_name: req.session.user.business_name,
                role: 'owner'
            },
            redirect: '/' // Redirect to dashboard
        });

    } catch (error) {
        logger.error('Login error:', error);
        res.status(500).json({
            success: false,
            message: 'Login failed. Please try again later.'
        });
    }
};

/**
 * Login for employees
 * Employees belong to a specific tenant
 */
const loginEmployee = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Validate input
        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Please provide email and password'
            });
        }

        // Find employee by email
        const employee = await authModel.findEmployeeByEmail(email);
        
        if (!employee) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password'
            });
        }

        // Check if employee is active
        if (employee.status !== 'Active') {
            return res.status(403).json({
                success: false,
                message: 'Your account is not active. Please contact your administrator.'
            });
        }

        // Check if account is locked
        if (employee.locked_until && new Date(employee.locked_until) > new Date()) {
            const remainingTime = Math.ceil((new Date(employee.locked_until) - new Date()) / 60000);
            return res.status(403).json({
                success: false,
                message: `Account is locked. Please try again in ${remainingTime} minutes.`
            });
        }

        // Verify password
        const isPasswordValid = await bcrypt.compare(password, employee.password);
        
        if (!isPasswordValid) {
            // Increment login attempts
            await authModel.incrementLoginAttempts(employee.id, 'employee');
            
            // Check if we should lock the account
            const updatedEmployee = await authModel.findEmployeeByEmail(email);
            if (updatedEmployee.login_attempts >= 5) {
                // Lock account for 15 minutes
                await authModel.lockAccount(employee.id, 15, 'employee');
                return res.status(403).json({
                    success: false,
                    message: 'Too many failed login attempts. Account locked for 15 minutes.'
                });
            }

            return res.status(401).json({
                success: false,
                message: 'Invalid email or password',
                remaining_attempts: 5 - updatedEmployee.login_attempts
            });
        }

        // Check if tenant is active
        const tenant = await authModel.findTenantById(employee.tenant_id);
        if (!tenant || !tenant.is_active) {
            return res.status(403).json({
                success: false,
                message: 'Business account is not active. Please contact support.'
            });
        }

        // Reset login attempts on successful login
        await authModel.resetLoginAttempts(employee.id, 'employee');

        // Update last login info
        const clientIp = req.ip || req.connection.remoteAddress;
        await authModel.updateLastLogin(employee.id, clientIp, 'employee');

        // Create session
        req.session.user = {
            id: employee.id,
            tenant_id: employee.tenant_id,
            name: employee.name,
            email: employee.email,
            business_name: tenant.business_name,
            role: employee.role,
            department: employee.department,
            isOwner: false,
            isEmployee: true
        };

        // Log successful login
        logger.info(`Employee login successful: ${email} (${employee.department || 'No Department'}) from IP: ${clientIp}`);

        // Determine redirect based on department only
        let redirectUrl = '/';
        const dept = employee.department ? employee.department.toLowerCase() : null;

        // Map department to their respective routes
        if (dept === 'finance') {
            redirectUrl = '/finance';
        } else if (dept === 'billing') {
            redirectUrl = '/billing';
        } else if (dept === 'hr') {
            redirectUrl = '/employee';
        } else if (dept === 'inventory') {
            redirectUrl = '/inventory';
        } else if (dept === 'sales') {
            redirectUrl = '/sales';
        }

        res.json({
            success: true,
            message: 'Login successful!',
            user: {
                name: req.session.user.name,
                email: req.session.user.email,
                business_name: req.session.user.business_name,
                role: req.session.user.role,
                department: req.session.user.department
            },
            redirect: redirectUrl
        });

    } catch (error) {
        logger.error('Employee login error:', error);
        res.status(500).json({
            success: false,
            message: 'Login failed. Please try again later.'
        });
    }
};

/**
 * Logout - destroys session
 */
const logout = (req, res) => {
    try {
        const userEmail = req.session.user ? req.session.user.email : 'unknown';
        
        req.session.destroy((err) => {
            if (err) {
                logger.error('Logout error:', err);
                return res.status(500).json({
                    success: false,
                    message: 'Logout failed'
                });
            }

            logger.info(`User logged out: ${userEmail}`);
            res.json({
                success: true,
                message: 'Logged out successfully',
                redirect: '/auth/login'
            });
        });
    } catch (error) {
        logger.error('Logout error:', error);
        res.status(500).json({
            success: false,
            message: 'Logout failed'
        });
    }
};

/**
 * Check authentication status
 */
const checkAuth = (req, res) => {
    if (req.session && req.session.user) {
        res.json({
            authenticated: true,
            user: {
                name: req.session.user.name,
                email: req.session.user.email,
                business_name: req.session.user.business_name,
                role: req.session.user.role,
                isOwner: req.session.user.isOwner || false
            }
        });
    } else {
        res.json({
            authenticated: false
        });
    }
};

module.exports = {
    showRegisterPage,
    showLoginPage,
    registerTenant,
    loginTenant,
    loginEmployee,
    logout,
    checkAuth
};
