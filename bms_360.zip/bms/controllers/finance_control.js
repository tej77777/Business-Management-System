const path = require('path');
const financeModel = require('../models/financeModel');

// Render finance page with calculated values
const getfinance = async (req, res) => {
    try {
        const tenantId = req.session.user.tenant_id;

        const [
            revenue, 
            expenses, 
            netProfit, 
            inventoryCost, 
            totalSalaries,
            todayIncome,
            todayExpenses,
            totalDiscount,
            totalGST,
            totalCustomerKhataPending,
            totalSupplierKhataPending,
            upcomingDueDates,
            customerKhataDetails
        ] = await Promise.all([
            financeModel.getTotalRevenue(tenantId),
            financeModel.getTotalExpenses(tenantId),
            financeModel.getNetProfitOrLoss(tenantId),
            financeModel.getInventoryCost(tenantId),
            financeModel.getTotalSalaries(tenantId),
            financeModel.getTodayIncome(tenantId),
            financeModel.getTodayExpenses(tenantId),
            financeModel.getTotalDiscount(tenantId),
            financeModel.getTotalGST(tenantId),
            financeModel.getTotalCustomerKhataPending(tenantId),
            financeModel.getTotalSupplierKhataPending(tenantId),
            financeModel.getUpcomingDueDates(tenantId),
            financeModel.getCustomerKhataDetails(tenantId)
        ]);
        
        res.render('finance.ejs', {
            user: req.session.user,
            totalRevenue: revenue,
            totalExpenses: expenses,
            netProfitOrLoss: netProfit,
            inventoryCost: inventoryCost,
            totalSalaries: totalSalaries,
            todayIncome: todayIncome,
            todayExpenses: todayExpenses,
            totalDiscount: totalDiscount,
            totalGST: totalGST,
            totalCustomerKhataPending: totalCustomerKhataPending,
            totalSupplierKhataPending: totalSupplierKhataPending,
            upcomingDueDates: upcomingDueDates,
            customerKhataDetails: customerKhataDetails
        });
    } catch (err) {
        console.error('Finance data error:', err);
        res.status(500).send('Error fetching finance data');
    }
};

// API endpoint to get detailed salary information for a specific month
const getSalaryDetails = async (req, res) => {
    try {
        const tenantId = req.session.user.tenant_id;
        const monthYear = req.query.month_year; // Expected format: YYYY-MM
        
        if (!monthYear || !/^\d{4}-\d{2}$/.test(monthYear)) {
            return res.status(400).json({ error: 'Invalid month_year format. Use YYYY-MM' });
        }
        
        const salaryDetails = await financeModel.getSalaryDetailsByMonth(tenantId, monthYear);
        res.json(salaryDetails);
    } catch (err) {
        console.error('Salary details error:', err);
        res.status(500).json({ error: 'Error fetching salary details' });
    }
};

// Add a new maintenance expense
const addMaintenanceExpense = async (req, res) => {
    try {
        const tenantId = req.session.user.tenant_id;
        const { entry_date, expense_type, brief, amount } = req.body;
        
        // Validate input
        if (!entry_date || !expense_type || !brief || !amount) {
            return res.status(400).json({ error: 'All fields are required' });
        }
        
        // Convert amount to number and validate
        const numAmount = parseFloat(amount);
        if (isNaN(numAmount) || numAmount <= 0) {
            return res.status(400).json({ error: 'Amount must be a positive number' });
        }
        
        // Add the expense to the database
        const expenseId = await financeModel.addMaintenanceExpense(tenantId, {
            entry_date, 
            expense_type, 
            brief, 
            amount: numAmount
        });
        
        // Get updated expense data
        const todayExpenses = await financeModel.getTodayExpenses(tenantId);
        const totalExpenses = await financeModel.getTotalExpenses(tenantId);
        
        res.status(201).json({ 
            success: true, 
            message: 'Expense added successfully',
            expenseId,
            updatedData: {
                todayExpenses,
                totalExpenses
            }
        });
    } catch (err) {
        console.error('Error adding maintenance expense:', err);
        res.status(500).json({ error: 'Failed to add expense' });
    }
};

// Get all maintenance expenses
const getAllMaintenanceExpenses = async (req, res) => {
    try {
        const tenantId = req.session.user.tenant_id;
        const expenses = await financeModel.getAllMaintenanceExpenses(tenantId);
        res.json(expenses);
    } catch (err) {
        console.error('Error fetching maintenance expenses:', err);
        res.status(500).json({ error: 'Failed to fetch expenses' });
    }
};

// Get today's expense details
const getTodayExpensesDetails = async (req, res) => {
    try {
        const tenantId = req.session.user.tenant_id;
        const expenses = await financeModel.getTodayExpensesDetails(tenantId);
        res.json(expenses);
    } catch (err) {
        console.error('Error fetching today\'s expense details:', err);
        res.status(500).json({ error: 'Failed to fetch today\'s expenses' });
    }
};

// Add a new supplier khata entry
const addSupplierKhata = async (req, res) => {
    try {
        const tenantId = req.session.user.tenant_id;
        const { supplier_name, phone_number, amount, due_date, khata_cycle } = req.body;
        
        // Validate input
        if (!supplier_name || !phone_number || !amount || !due_date || !khata_cycle) {
            return res.status(400).json({ error: 'All fields are required' });
        }
        
        // Validate phone number
        if (!/^\d{10}$/.test(phone_number)) {
            return res.status(400).json({ error: 'Phone number must be 10 digits' });
        }
        
        // Convert amount to number and validate
        const numAmount = parseFloat(amount);
        if (isNaN(numAmount) || numAmount <= 0) {
            return res.status(400).json({ error: 'Amount must be a positive number' });
        }
        
        // Convert khata_cycle to number and validate
        const numKhataCycle = parseInt(khata_cycle);
        if (isNaN(numKhataCycle) || numKhataCycle <= 0) {
            return res.status(400).json({ error: 'Khata cycle must be a positive number' });
        }
        
        // Add the entry to the database
        const today = new Date().toISOString().split('T')[0]; // Current date for entry_date
        const khataId = await financeModel.addSupplierKhata(tenantId, {
            entry_date: today,
            supplier_name,
            phone_number,
            amount: numAmount,
            due_date,
            khata_cycle: numKhataCycle
        });
        
        // Get updated supplier khata data
        const totalSupplierKhataPending = await financeModel.getTotalSupplierKhataPending(tenantId);
        const upcomingDueDates = await financeModel.getUpcomingDueDates(tenantId);
        
        res.status(201).json({ 
            success: true, 
            message: 'Supplier khata added successfully',
            khataId,
            updatedData: {
                totalSupplierKhataPending,
                upcomingDueDates
            }
        });
    } catch (err) {
        console.error('Error adding supplier khata:', err);
        res.status(500).json({ error: 'Failed to add supplier khata' });
    }
};

// Get all supplier khata entries
const getAllSupplierKhata = async (req, res) => {
    try {
        const tenantId = req.session.user.tenant_id;
        const khataEntries = await financeModel.getAllSupplierKhata(tenantId);
        res.json(khataEntries);
    } catch (err) {
        console.error('Error fetching supplier khata entries:', err);
        res.status(500).json({ error: 'Failed to fetch supplier khata entries' });
    }
};

// Get customer khata details
const getCustomerKhataDetails = async (req, res) => {
    try {
        const tenantId = req.session.user.tenant_id;
        const khataDetails = await financeModel.getCustomerKhataDetails(tenantId);
        res.json(khataDetails);
    } catch (err) {
        console.error('Error fetching customer khata details:', err);
        res.status(500).json({ error: 'Failed to fetch customer khata details' });
    }
};

// Update bill payment method (from Credit to Cash/UPI)
const updateBillPaymentMethod = async (req, res) => {
    try {
        const tenantId = req.session.user.tenant_id;
        const { billId, paymentMethod } = req.body;
        
        // Validate input
        if (!billId || !paymentMethod) {
            return res.status(400).json({ error: 'Bill ID and payment method are required' });
        }
        
        // Validate payment method
        if (!['Cash', 'UPI', 'Debit', 'Card'].includes(paymentMethod)) {
            return res.status(400).json({ error: 'Payment method must be Cash, UPI, Debit, or Card' });
        }
        
        // Update the bill's payment method
        const success = await financeModel.updateBillPaymentMethod(tenantId, billId, paymentMethod);
        
        if (!success) {
            return res.status(404).json({ error: 'Bill not found or already paid' });
        }
        
        // Get updated khata data
        const totalCustomerKhataPending = await financeModel.getTotalCustomerKhataPending(tenantId);
        const customerKhataDetails = await financeModel.getCustomerKhataDetails(tenantId);
        
        res.status(200).json({ 
            success: true, 
            message: 'Payment recorded successfully',
            updatedData: {
                totalCustomerKhataPending,
                customerKhataDetails
            }
        });
    } catch (err) {
        console.error('Error updating bill payment:', err);
        res.status(500).json({ error: 'Failed to update payment' });
    }
};

// Pay a specific supplier khata entry
const paySupplierKhata = async (req, res) => {
    try {
        const tenantId = req.session.user.tenant_id;
        const { id } = req.params;
        
        if (!id || isNaN(id)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid supplier ID'
            });
        }
        
        // Pay the specific supplier khata entry
        const result = await financeModel.paySupplierKhata(tenantId, id);
        
        if (result === 0) {
            return res.status(404).json({
                success: false,
                message: 'Supplier khata entry not found'
            });
        }
        
        // Get the updated total supplier khata pending amount
        const updatedTotalPending = await financeModel.getTotalSupplierKhataPending(tenantId);
        
        res.json({
            success: true,
            message: 'Supplier payment marked as complete',
            updatedTotalPending
        });
    } catch (error) {
        console.error('Error paying supplier khata:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to process supplier payment: ' + error.message
        });
    }
};

// Clear all supplier khata entries
const clearAllSupplierKhata = async (req, res) => {
    try {
        const tenantId = req.session.user.tenant_id;
        
        // Clear all supplier khata entries
        const rowsAffected = await financeModel.clearAllSupplierKhata(tenantId);
        
        res.json({
            success: true,
            message: `All supplier khata entries have been cleared (${rowsAffected} entries)`
        });
    } catch (error) {
        console.error('Error clearing all supplier khata entries:', error);
        res.status(500).json({
            success: false,
            message: 'Failed to clear all supplier khata entries'
        });
    }
};

// Get all expenses details (inventory, salary, maintenance)
const getAllExpensesDetails = async (req, res) => {
    try {
        const tenantId = req.session.user.tenant_id;
        
        // Get current month-year for salary details
        const date = new Date();
        const currentMonthYear = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
        
        const [
            inventoryItems,
            salaryDetails,
            maintenanceExpenses,
            inventoryExpense,
            salaryExpense,
            maintenanceExpense
        ] = await Promise.all([
            financeModel.getInventoryItems(tenantId),
            financeModel.getSalaryDetailsByMonth(tenantId, currentMonthYear),
            financeModel.getAllMaintenanceExpenses(tenantId),
            financeModel.getInventoryCost(tenantId),
            financeModel.getTotalSalaries(tenantId),
            financeModel.getMaintenanceExpensesTotal(tenantId)
        ]);
        
        res.json({
            inventoryItems,
            salaryDetails,
            maintenanceExpenses,
            inventoryExpense,
            salaryExpense,
            maintenanceExpense
        });
    } catch (err) {
        console.error('Error fetching all expenses details:', err);
        res.status(500).json({ error: 'Failed to fetch expenses details' });
    }
};

module.exports = { 
    getfinance, 
    getSalaryDetails,
    addMaintenanceExpense,
    getAllMaintenanceExpenses,
    getTodayExpensesDetails,
    addSupplierKhata,
    getAllSupplierKhata,
    getCustomerKhataDetails,
    updateBillPaymentMethod,
    paySupplierKhata,
    clearAllSupplierKhata,
    getAllExpensesDetails
};

