const emp_dtModel = require('../models/emp_dtModel');

// Function to get employee details including profile, salary, and attendance
const getEmployeeDetails = async (req, res) => {
    try {
        const employeeId = req.params.id;
        const tenantId = req.session.user.tenant_id; // Get tenant_id from session
        
        // Get employee profile details with tenant isolation
        const profileResult = await emp_dtModel.getEmployeeProfile(employeeId, tenantId);
        
        // Get employee salary details with tenant isolation
        const salaryResult = await emp_dtModel.getEmployeeSalary(employeeId, tenantId);
        
        // Get employee attendance details with tenant isolation
        const attendanceResult = await emp_dtModel.getEmployeeAttendance(employeeId, tenantId);
        
        if (profileResult.success) {
            // Render the emp_dt page with all data
            res.render('emp_dt', { 
                user: req.session.user,
                profile: profileResult.data,
                salary: salaryResult.success ? salaryResult.data : [],
                attendance: attendanceResult.success ? attendanceResult.data : [],
                title: 'Employee Details'
            });
        } else {
            res.status(404).render('emp_dt', { 
                user: req.session.user,
                error: "Employee not found",
                title: 'Employee Details'
            });
        }
    } catch (error) {
        console.error("Error in controller:", error);
        res.status(500).render('emp_dt', { 
            user: req.session.user,
            error: "An error occurred while fetching employee details",
            title: 'Employee Details'
        });
    }
};

module.exports = {
    getEmployeeDetails
};
