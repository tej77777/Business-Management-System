const path = require('path');
const indexModel = require('../models/indexModel');

// Controller function to render the dashboard
const getindex = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        
        // Gather all dashboard data using functions from indexModel
        const dashboardData = {
            // Today's Highlights
            totalSalesToday: await indexModel.getTotalSalesToday(tenant_id),
            billsMadeToday: await indexModel.getBillsMadeToday(tenant_id),
            itemsSoldToday: await indexModel.getItemsSoldToday(tenant_id),
            
            // Finance Glance
            cashInHand: await indexModel.getCashInHand(tenant_id),
            expensesToday: await indexModel.getExpensesToday(tenant_id),
            pendingCustomerKhata: await indexModel.getPendingCustomerKhata(tenant_id),
            
            // Inventory Watch
            lowStockItems: await indexModel.getLowStockItems(tenant_id, 10), // items with stock ≤ 10
            newStockAddedToday: await indexModel.getNewStockAddedToday(tenant_id),
            outOfStockProducts: await indexModel.getOutOfStockProducts(tenant_id)
        };

        // Render the index.ejs view with the dashboard data
        res.render('index', {
            ...dashboardData,
            pageTitle: 'Dashboard',
            activePage: 'dashboard'
        });
    } catch (error) {
        console.error('Dashboard data fetch error:', error);
        // In case of error, render the page with default values
        res.render('index', {
            totalSalesToday: 0,
            billsMadeToday: 0,
            itemsSoldToday: 0,
            cashInHand: 0,
            expensesToday: 0,
            pendingCustomerKhata: 0,
            lowStockItems: 0,
            newStockAddedToday: 0,
            outOfStockProducts: 0,
            error: 'Failed to load dashboard data',
            pageTitle: 'Dashboard',
            activePage: 'dashboard'
        });
    }
};

module.exports = { getindex };
