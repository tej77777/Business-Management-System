const salesModel = require('../models/salesModel');

// Raw helpers for rendering dashboard (return value directly, not JSON)
exports.totalProfitRaw = async (tenant_id) => {
    return await salesModel.getTotalProfit(tenant_id);
};

exports.totalSalesRaw = async (tenant_id) => {
    return await salesModel.getTotalSales(tenant_id);
};

exports.numberOfBillsRaw = async (tenant_id) => {
    return await salesModel.getNumberOfBills(tenant_id);
};

exports.paymentTypeSplitsRaw = async (tenant_id) => {
    const data = await salesModel.getPaymentTypeSplits(tenant_id);
    // Additional data validation for frontend
    if (data && Array.isArray(data)) {
        // Make sure percentage is always a valid number
        return data.map(item => ({
            ...item,
            percentage: isNaN(item.percentage) ? 0 : item.percentage
        }));
    }
    return data;
};

exports.top5ProductsRaw = async (tenant_id) => {
    return await salesModel.getTop5Products(tenant_id);
};

exports.bottom5ProductsRaw = async (tenant_id) => {
    return await salesModel.getBottom5Products(tenant_id);
};

exports.cashInHandRaw = async (tenant_id) => {
    return await salesModel.getCashInHand(tenant_id);
};

// Controller for Total Profit
exports.totalProfit = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        const profit = await salesModel.getTotalProfit(tenant_id);
        res.json({ totalProfit: profit });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Controller for Total Sales (Revenue)
exports.totalSales = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        const sales = await salesModel.getTotalSales(tenant_id);
        res.json({ totalSales: sales });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Controller for Number of Bills
exports.numberOfBills = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        const count = await salesModel.getNumberOfBills(tenant_id);
        res.json({ numberOfBills: count });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Controller for Payment Type Splits
exports.paymentTypeSplits = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        const splits = await salesModel.getPaymentTypeSplits(tenant_id);
        
        // Make sure percentages are valid before sending to frontend
        const validatedSplits = splits.map(item => ({
            ...item,
            percentage: isNaN(item.percentage) ? 0 : item.percentage
        }));
        
        res.json({ paymentTypeSplits: validatedSplits });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Controller for Top 5 Products (By Quantity Sold)
exports.top5Products = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        const products = await salesModel.getTop5Products(tenant_id);
        res.json({ top5Products: products });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Controller for Low Performing Products (Bottom 5 by Quantity Sold)
exports.bottom5Products = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        const products = await salesModel.getBottom5Products(tenant_id);
        res.json({ bottom5Products: products });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};
// Controller for Category-wise sales
exports.categorySalesRaw = async (tenant_id) => {
    return await salesModel.getCategorySales(tenant_id);
};

exports.categorySales = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        const categorySales = await salesModel.getCategorySales(tenant_id);
        res.json({ categorySales: categorySales });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Controller for Cash in Hand (Cash + UPI only)
exports.cashInHand = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        const cash = await salesModel.getCashInHand(tenant_id);
        res.json({ cashInHand: cash });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

// Raw helpers for Customer Behavior Analysis
exports.ageGroupTrendsRaw = async (tenant_id) => {
    return await salesModel.getAgeGroupTrends(tenant_id);
};

exports.customerLoyaltyDataRaw = async (tenant_id) => {
    return await salesModel.getCustomerLoyaltyData(tenant_id);
};

exports.averageBasketSizeRaw = async (tenant_id) => {
    return await salesModel.getAverageBasketSize(tenant_id);
};

exports.paymentPreferencesRaw = async (tenant_id) => {
    return await salesModel.getPaymentPreferences(tenant_id);
};

// Controllers for Customer Behavior Analysis
exports.ageGroupTrends = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        const trends = await salesModel.getAgeGroupTrends(tenant_id);
        res.json({ ageGroupTrends: trends });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.customerLoyaltyData = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        const loyaltyData = await salesModel.getCustomerLoyaltyData(tenant_id);
        res.json({ customerLoyaltyData: loyaltyData });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.averageBasketSize = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        const basketSize = await salesModel.getAverageBasketSize(tenant_id);
        res.json({ averageBasketSize: basketSize });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};

exports.paymentPreferences = async (req, res) => {
    try {
        const tenant_id = req.session.user.tenant_id;
        const preferences = await salesModel.getPaymentPreferences(tenant_id);
        res.json({ paymentPreferences: preferences });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
};