// Generate secure session secret for production
// Run: node generate-secret.js

const crypto = require('crypto');

console.log('\n🔐 Secure Session Secret Generator\n');
console.log('Copy this value to your SESSION_SECRET environment variable on Render:\n');
console.log('─'.repeat(80));
console.log(crypto.randomBytes(32).toString('hex'));
console.log('─'.repeat(80));
console.log('\n✅ This is a cryptographically secure random string.\n');
console.log('📋 Usage:');
console.log('   1. Copy the value above');
console.log('   2. In Render dashboard, go to your web service');
console.log('   3. Navigate to Environment tab');
console.log('   4. Set SESSION_SECRET to this value\n');
